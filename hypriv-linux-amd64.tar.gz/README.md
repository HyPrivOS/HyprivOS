# HyPriv OS Server Management Platform

This repository contains the source code and installation scripts for HyPriv OS. 

## 🚀 How to Create a New Release (Build)

When you make changes to the source code and want to deploy a new version, you need to create a compressed build archive (`.tar.gz`). We have a script that automates this.

### Step 1: Run the Build Script

Run the following command from the root of this project:

```bash
./build.sh
```

**What this does:**
- Deletes any old build files.
- Packages all necessary code into `hypriv-linux-amd64.tar.gz`.
- Generates a checksum file `hypriv-linux-amd64.tar.gz.sha256` (used for security verification during installation).
- Excludes unnecessary files like `node_modules`, `.git`, `build.sh`, and `install.sh`.

### Step 2: Upload to Production Server

After the script finishes, two new files will be generated in your project folder:
1. `hypriv-linux-amd64.tar.gz`
2. `hypriv-linux-amd64.tar.gz.sha256`

You must upload **both** of these files to your hosting provider/CDN (like AWS S3, Cloudflare R2, or a custom Nginx server) so that they are accessible at the exact URL specified in `install.sh`.

Currently, `install.sh` looks for these files at:
- `https://download.hypriv.com/releases/latest/hypriv-linux-amd64.tar.gz`
- `https://download.hypriv.com/releases/latest/hypriv-linux-amd64.tar.gz.sha256`

---

## 🌍 How to Setup Production Installation

Once your build files are uploaded to the `download.hypriv.com` server, you are ready to allow users to install your software via a direct command.

### 1. Update `install.sh` (If not done already)
Before distributing the script, ensure you have uncommented the download section in `install.sh`.

**Change this:**
```bash
# echo -e "Downloading official release package..."
# curl -sSL -o hypriv.tar.gz "$RELEASE_URL"
# curl -sSL -o hypriv.tar.gz.sha256 "$CHECKSUM_URL"
# sha256sum -c hypriv.tar.gz.sha256 || { echo -e "\e[1;31mChecksum verification failed.\e[0m"; exit 1; }
# tar -xzf hypriv.tar.gz -C "$APP_DIR"
# rm -f hypriv.tar.gz hypriv.tar.gz.sha256

# Note: Since the official package isn't available right now for local dev testing...
if [ -d "/home/ayesha/Projects/ngnix-Server" ]; then
  sudo cp -r /home/ayesha/Projects/ngnix-Server/* "$APP_DIR/"
  sudo chown -R hypriv:hypriv "$APP_DIR"
fi
```

**To this (Production Ready):**
```bash
echo -e "Downloading official release package..."
curl -sSL -o hypriv.tar.gz "$RELEASE_URL"
curl -sSL -o hypriv.tar.gz.sha256 "$CHECKSUM_URL"
sha256sum -c hypriv.tar.gz.sha256 || { echo -e "\e[1;31mChecksum verification failed.\e[0m"; exit 1; }
tar -xzf hypriv.tar.gz -C "$APP_DIR"
rm -f hypriv.tar.gz hypriv.tar.gz.sha256
```

### 2. Host `install.sh` Publicly
Upload the modified `install.sh` file to a place where users can fetch it directly (e.g., GitHub Raw, or your main website server). 

If you host it on `https://hypriv.com/install.sh`, users will install your software by running:

```bash
curl -sL https://hypriv.com/install.sh | sudo bash
```

---

## 💻 Local Testing (Without uploading to a server)

If you just want to test if the `install.sh` script works locally without uploading anything to `download.hypriv.com`, you can keep the local override active in `install.sh`:

```bash
# Local testing fallback
if [ -d "/home/ayesha/Projects/ngnix-Server" ]; then
  sudo cp -r /home/ayesha/Projects/ngnix-Server/* "$APP_DIR/"
  sudo chown -R hypriv:hypriv "$APP_DIR"
fi
```
And run the script manually:
```bash
sudo ./install.sh
```

---

## 🛠 Project Structure

- **`install.sh`**: The main setup script that customers run to install HyPriv OS.
- **`build.sh`**: Developer script used to compile the `.tar.gz` and `.sha256` files.
- **`app.js`**: Main Node.js application entry point.
- **`package.json`**: Application dependencies.
