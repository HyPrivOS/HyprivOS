# HyPriv OS Server Management Platform

This repository contains the source code and installation scripts for HyPriv OS. 

## 🚀 How to Create a New Release (Build)

When you make changes to the source code and want to deploy a new version, you need to create a compressed build archive (`.tar.gz`). We have a script that automates this.

### Step 1: Run the Build Script

Run the following command from the root of this project:

```bash
./build.sh
```

**What this does:**
- Deletes any old build files.
- Packages all necessary code into `hypriv-linux-amd64.tar.gz`.
- Generates a checksum file `hypriv-linux-amd64.tar.gz.sha256` (used for security verification during installation).
- Excludes unnecessary files like `node_modules`, `.git`, `build.sh`, and `install.sh`.

### Step 2: Upload to Production Server

After the script finishes, two new files will be generated in your project folder:
1. `hypriv-linux-amd64.tar.gz`
2. `hypriv-linux-amd64.tar.gz.sha256`

You must upload **both** of these files to your GitHub repository (e.g., as a release or directly in the repo) so that they are accessible at the exact URL specified in `install.sh`.

Since you are hosting on GitHub at `https://github.com/HyPrivOS/HyprivOS`, `install.sh` uses the raw GitHub URLs:
- `https://raw.githubusercontent.com/HyPrivOS/HyprivOS/main/hypriv-linux-amd64.tar.gz`
- `https://raw.githubusercontent.com/HyPrivOS/HyprivOS/main/hypriv-linux-amd64.tar.gz.sha256`

---

## 🌍 How to Setup Production Installation

Since your build files and `install.sh` are uploaded to the GitHub repository, users can install your software via a direct command.

### 1. Distribute the Install Command
Your `install.sh` is now publicly accessible via GitHub. Users can install your software by running:

```bash
curl -sL https://raw.githubusercontent.com/HyPrivOS/HyprivOS/main/install.sh | sudo bash
```

---

## 💻 Local Testing (Without uploading to a server)

If you just want to test if the `install.sh` script works locally without fetching from GitHub, you can re-enable the local override block in `install.sh`:

```bash
# Local testing fallback
if [ -d "/home/ayesha/Projects/ngnix-Server" ]; then
  sudo cp -r /home/ayesha/Projects/ngnix-Server/* "$APP_DIR/"
  sudo chown -R hypriv:hypriv "$APP_DIR"
fi
```
And run the script manually:
```bash
sudo ./install.sh
```

---

## 🛠 Project Structure

- **`install.sh`**: The main setup script that customers run to install HyPriv OS.
- **`build.sh`**: Developer script used to compile the `.tar.gz` and `.sha256` files.
- **`app.js`**: Main Node.js application entry point.
- **`package.json`**: Application dependencies.
