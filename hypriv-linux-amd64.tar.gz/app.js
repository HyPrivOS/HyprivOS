const express = require('express');
const session = require('express-session');
const nodemailer = require('nodemailer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cronParser = require('cron-parser');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs').promises;
const fsSync = require('fs');
const { execFile, spawn } = require('child_process');
const os = require('os');
const crypto = require('crypto');
const dns = require('dns').promises;
const multer = require('multer');
const archiver = require('archiver');
const pkg = require('./package.json');
const AdmZip = require('adm-zip');
const bcrypt = require('bcryptjs');

dotenv.config();

const app = express();
app.set('trust proxy', 1);

// ==================== CONFIGURATION (JSON) ====================
const HYPRIV_CONFIG = path.join(__dirname, 'HyprivOS.config.json');
try { fsSync.mkdirSync(path.join(__dirname, 'data'), { recursive: true }); } catch (e) {}

function loadHyprivConfig() {
  try {
    return JSON.parse(fsSync.readFileSync(HYPRIV_CONFIG, 'utf8'));
  } catch(e) {
    return {
      adminUser: 'admin', adminPassHash: null, twoFactorEnabled: false,
      emailConfig: { host: '', port: 465, secure: true, user: '', pass: '', from: '', cc: '', to: '' },
      allowedIps: process.env.ALLOWED_IP_RANGE || '*',
      ide_allowed_root: process.env.IDE_ALLOWED_ROOT || '/home/' + (process.env.USER || 'ayesha')
    };
  }
}
function saveHyprivConfig(config) {
  fsSync.writeFileSync(HYPRIV_CONFIG, JSON.stringify(config, null, 2));
}

function loadAuthPrefs() { return loadHyprivConfig(); }
function saveAuthPrefs(p) { const c = loadHyprivConfig(); Object.assign(c, p); saveHyprivConfig(c); }

function loadSettings() { return loadHyprivConfig(); }
function saveSettingsFile(p) { const c = loadHyprivConfig(); c.emailConfig = p.emailConfig; saveHyprivConfig(c); }

function loadSecurityPrefs() { return loadHyprivConfig(); }
function saveSecurityPrefs(p) { 
  const c = loadHyprivConfig(); 
  if (p.allowedIps) c.allowedIps = p.allowedIps; 
  if (p.ideAllowedRoot) c.ide_allowed_root = p.ideAllowedRoot;
  saveHyprivConfig(c); 
}

app.use((req, res, next) => {
  try {
    const prefs = loadSecurityPrefs();
    const allowedPattern = prefs.allowedIps || '*';
    if (allowedPattern === '*') return next(); // Allow all if *
    
    let clientIp = req.ip || req.connection?.remoteAddress || '';
    if (clientIp.startsWith('::ffff:')) clientIp = clientIp.slice(7);

    const patterns = allowedPattern.split(',').map(p => p.trim()).filter(Boolean);
    let isAllowed = false;

    for (const p of patterns) {
      if (p === '*') { isAllowed = true; break; }
      const regexStr = '^' + p.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$';
      if (new RegExp(regexStr).test(clientIp)) {
        isAllowed = true;
        break;
      }
    }

    if (!isAllowed) {
      return res.status(403).send('Forbidden: Access is denied from your IP address.');
    }
  } catch (e) {
    // If it fails, proceed normally or handle
  }
  next();
});

const PORT = process.env.PORT || 3000;
const IS_WINDOWS = process.platform === 'win32';
const activeTasks = new Map();

function getIdeAllowedRoot() {
  try {
    if (fsSync.existsSync(HYPRIV_CONFIG)) {
      const prefs = JSON.parse(fsSync.readFileSync(HYPRIV_CONFIG, 'utf8'));
      if (prefs.ide_allowed_root) {
        return path.resolve(prefs.ide_allowed_root);
      }
    }
  } catch (e) {}
  return process.env.IDE_ALLOWED_ROOT ? path.resolve(process.env.IDE_ALLOWED_ROOT) : path.resolve('/home/' + (process.env.USER || 'ayesha'));
}
// ==================== NOTIFICATION PREFS & COOLDOWN ====================
const NOTIF_PREFS_FILE = path.join(__dirname, 'notification_prefs.json');
const PROCESS_HISTORY_FILE = path.join(__dirname, 'process_history.json');
const PROCESS_LOGS_DIR = path.join(__dirname, '.process_logs');
const ALERT_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes cooldown
const lastAlertTime = new Map(); // domain -> timestamp

// Ensure process logs directory exists
try { fsSync.mkdirSync(PROCESS_LOGS_DIR, { recursive: true }); } catch(e) {}

function loadNotifPrefs() {
  try {
    return JSON.parse(fsSync.readFileSync(NOTIF_PREFS_FILE, 'utf8'));
  } catch(e) {
    return {}; // empty = all disabled by default
  }
}

function saveNotifPrefs(prefs) {
  fsSync.writeFileSync(NOTIF_PREFS_FILE, JSON.stringify(prefs, null, 2));
}

function loadProcessHistory() {
  try {
    return JSON.parse(fsSync.readFileSync(PROCESS_HISTORY_FILE, 'utf8'));
  } catch(e) {
    return [];
  }
}

function saveProcessHistory(history) {
  // Keep only last 100 entries
  const trimmed = history.slice(-100);
  fsSync.writeFileSync(PROCESS_HISTORY_FILE, JSON.stringify(trimmed, null, 2));
}

function appendProcessLog(taskId, text) {
  try {
    const logFile = path.join(PROCESS_LOGS_DIR, `${taskId}.log`);
    fsSync.appendFileSync(logFile, text);
    // Trim to last 500 lines if too large
    const content = fsSync.readFileSync(logFile, 'utf8');
    const lines = content.split('\n');
    if (lines.length > 500) {
      fsSync.writeFileSync(logFile, lines.slice(-500).join('\n'));
    }
  } catch(e) {}
}

function isSafeIdePath(p) {
  const resolved = path.resolve(p);
  const allowedRoot = getIdeAllowedRoot();
  return resolved === allowedRoot || resolved.startsWith(allowedRoot + path.sep);
}

// ==================== SECURITY: Input Validators ====================
const DOMAIN_RE = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
const CRON_CMD_WHITELIST = [
  'systemctl restart nginx',
  'systemctl reload nginx',
  'nginx -t',
  'certbot renew --quiet',
  'find /var/log/nginx -name "*.log" -mtime +30 -delete',
  'gzip /var/log/nginx/*.log.*',
  'systemctl restart php*-fpm',
  'apt update && apt upgrade -y',
];

function isValidDomain(d) {
  return typeof d === 'string' && d.length > 0 && d.length <= 253 && DOMAIN_RE.test(d);
}
function isValidPortOrPath(p) {
  if (typeof p !== 'string') p = String(p);
  if (p.startsWith('/')) return true;
  const n = parseInt(p, 10);
  return Number.isFinite(n) && n >= 1 && n <= 65535;
}
function sanitizeDomain(d) {
  if (!isValidDomain(d)) return null;
  return d.toLowerCase().trim();
}

function isValidFileName(f) {
  return typeof f === 'string' && f.length > 0 && f.length <= 255 && /^[\w.-]+$/.test(f) && !f.includes('..');
}

function sanitizeFileName(f) {
  if (!isValidFileName(f)) return null;
  return f.trim();
}
function sanitizeConfigContent(c) {
  if (typeof c !== 'string') return null;
  // Block backticks only ($ is needed for nginx variables like $host, $http_upgrade)
  if (/`/.test(c)) return null;
  return c;
}

// ==================== SECURITY: Helmet Headers ====================
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
      scriptSrcAttr: ["'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com"],
      imgSrc: ["'self'", "data:"],
      workerSrc: ["'self'", "blob:"],
      connectSrc: ["'self'", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net", "ws:", "wss:"],
      upgradeInsecureRequests: null,
    }
  },
  crossOriginOpenerPolicy: false,
  originAgentCluster: false,
}));

// ==================== Middleware ====================
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));
app.use(express.static('public'));

// ==================== SECURITY: Rate Limiting ====================
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: 'Too many OTP requests. Try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  message: { error: 'Too many requests. Slow down.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ==================== Session Configuration ====================
const sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret || sessionSecret === 'your-super-secret-key-change-this') {
  console.warn('⚠️  WARNING: Using default session secret! Set SESSION_SECRET in .env');
}

const sessionMiddleware = session({
  // Using default MemoryStore. This wipes all sessions on server restart.
  secret: sessionSecret || crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    // No maxAge: Makes it a browser-session cookie (clears when browser closes)
    httpOnly: true,
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
  }
});
app.use(sessionMiddleware);

// ==================== CSRF Token Middleware ====================
app.use((req, res, next) => {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  res.locals.csrfToken = req.session.csrfToken;
  next();
});

function verifyCsrf(req, res, next) {
  const token = req.body._csrf || req.headers['x-csrf-token'];
  if (!token || token !== req.session.csrfToken) {
    if (req.xhr || (req.headers.accept && req.headers.accept.includes('json'))) {
      return res.status(403).json({ error: 'Invalid security token. Please refresh the page.' });
    }
    return res.redirect('/');
  }
  next();
}

app.get('/login', (req, res) => res.redirect('/'));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ==================== Email Configuration ====================
function getTransporter() {
  const s = loadSettings().emailConfig || {};
  if (!s.host || !s.user) return null;
  return nodemailer.createTransport({
    host: s.host,
    port: parseInt(s.port) || 465,
    secure: s.secure !== false,
    auth: { user: s.user, pass: s.pass },
    tls: { rejectUnauthorized: false }
  });
}

// OTP store (in-memory)
const otpStore = new Map();

// Domain Status Cache
const domainStatusCache = {};

function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

async function sendOTPEmail(email, otp) {
  try {
    const transporter = getTransporter();
    if (!transporter) throw new Error('Email settings not configured');
    const s = loadSettings().emailConfig || {};
    const mailOptions = {
      from: s.from || 'noreply@hypriv.com',
      to: email,
      cc: s.cc || '',
      subject: 'Your HyPrive OS Login OTP',
      html: `
        <!DOCTYPE html><html><head><style>
          body{font-family:Arial,sans-serif;background:#0a0a0f;padding:20px;color:#fff}
          .c{max-width:420px;margin:0 auto;background:#15151f;padding:28px;border-radius:8px;border:1px solid rgba(255,255,255,0.06)}
          .h{text-align:center;border-bottom:1px solid rgba(255,255,255,0.06);padding-bottom:16px;margin-bottom:16px}
          .h h2{color:#818cf8;margin:0;font-size:18px}
          .otp{font-size:32px;font-weight:700;color:#6366f1;text-align:center;padding:16px;letter-spacing:8px;font-family:monospace}
          .f{text-align:center;margin-top:16px;color:rgba(255,255,255,0.4);font-size:11px}
          p{color:rgba(255,255,255,0.6);text-align:center;font-size:13px;margin:8px 0}
        </style></head><body>
          <div class="c">
            <div class="h">
              <img src="https://hypriv.com/pic/hypriv.svg" alt="HyPrive OS Logo" style="height: 40px; margin-bottom:10px;">
              <h2>🔐 HyPrive OS</h2><p>Login Verification</p>
            </div>
            <div class="otp">${otp}</div>
            <p>This OTP is valid for <strong>5 minutes</strong>. Do not share.</p>
            <hr style="border-color:rgba(255,255,255,0.06)">
            <div class="f">
              <p>Automated email from HyPrive OS.</p>
              <p><a href="https://hypriv.com" style="color:#818cf8;">hypriv.com</a> | +91 858 001 0008</p>
            </div>
          </div>
        </body></html>`
    };
    await transporter.sendMail(mailOptions);
    console.log('✅ OTP sent');
    return true;
  } catch (err) {
    console.error('❌ Email error:', err.message);
    return false;
  }
}

async function sendDomainAlertEmail(domain, isLive) {
  try {
    const transporter = getTransporter();
    if (!transporter) throw new Error('Email settings not configured');
    const s = loadSettings().emailConfig || {};
    const statusText = isLive ? 'UP / LIVE' : 'DOWN / STOPPED';
    const statusEmoji = isLive ? '✅' : '🔴';
    const statusColor = isLive ? '#10b981' : '#ef4444';
    const statusBg = isLive ? '#ecfdf5' : '#fef2f2';
    const statusBorder = isLive ? '#a7f3d0' : '#fecaca';
    const headerBg = isLive ? '#059669' : '#dc2626';
    const email = s.to || process.env.USER_EMAIL;
    const timestamp = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    if (!email) return false;

    const mailOptions = {
      from: s.from || 'noreply@hypriv.com',
      to: email,
      cc: s.cc || '',
      subject: `Domain Status Alert: ${domain} is ${isLive ? 'LIVE' : 'DOWN'}`,
      html: `
        <!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"></head>
        <body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:20px;">
            <tr><td align="center">
              <table width="480" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
                <!-- Header Bar -->
                <tr><td style="background:${headerBg};padding:24px;text-align:center;">
                  <img src="https://hypriv.com/pic/hypriv.svg" alt="HyPrive OS" style="height:40px; margin-bottom:16px;">
                  <div>
                    <span style="font-size:28px;">${statusEmoji}</span>
                    <h1 style="color:#ffffff;font-size:20px;margin:8px 0 0;font-weight:700;letter-spacing:0.5px;">
                      Domain ${isLive ? 'is LIVE' : 'is DOWN'}
                    </h1>
                  </div>
                </td></tr>
                <!-- Domain Name -->
                <tr><td style="padding:24px 24px 16px;text-align:center;">
                  <div style="background:#f8f9fa;border:2px solid ${statusBorder};border-radius:8px;padding:16px;margin:0 auto;">
                    <span style="font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:1px;font-weight:600;">Domain</span>
                    <p style="font-size:22px;font-weight:700;color:#111827;margin:6px 0 0;word-break:break-all;">${domain}</p>
                  </div>
                </td></tr>
                <!-- Status Box -->
                <tr><td style="padding:0 24px 16px;text-align:center;">
                  <div style="background:${statusBg};border:1px solid ${statusBorder};border-radius:8px;padding:14px;">
                    <span style="font-size:14px;font-weight:700;color:${statusColor};">
                      Status: ${statusText}
                    </span>
                  </div>
                </td></tr>
                <!-- Timestamp -->
                <tr><td style="padding:0 24px 24px;text-align:center;">
                  <table width="100%" style="border-top:1px solid #e5e7eb;padding-top:16px;">
                    <tr>
                      <td style="font-size:11px;color:#9ca3af;text-align:center;">
                        <span style="font-weight:600;">Detected at:</span> ${timestamp} (IST)
                      </td>
                    </tr>
                  </table>
                </td></tr>
                <!-- Footer -->
                <tr>
                  <td align="center" style="padding:16px;background:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;color:#64748b;">
                    <p style="margin:0;"><a href="https://hypriv.com" style="color:#64748b;text-decoration:none;">HyPrive OS Support</a> • +91 858 001 0008</p>
                    <p style="margin:4px 0 0 0;">Automated status alert from your server.</p>
                  </td>
                </tr>
              </table>
            </td></tr>
          </table>
        </body></html>`
    };
    await transporter.sendMail(mailOptions);
    console.log(`✅ Alert sent for ${domain}: ${statusText}`);
    return true;
  } catch (err) {
    console.error('❌ Alert Email error:', err.message);
    return false;
  }
}

// ==================== Auth Middleware ====================
function requireAuth(req, res, next) {
  if (!req.session.isAuthenticated) {
    if (req.xhr || req.headers.accept?.includes('json')) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    return res.redirect('/');
  }
  next();
}

// ==================== SAFE Nginx Functions (No exec!) ====================
const NGINX_SITES_AVAILABLE = '/etc/nginx/sites-available/';
const NGINX_SITES_ENABLED = '/etc/nginx/sites-enabled/';

// Safe execFile wrapper — only whitelisted commands
function safeExecFile(cmd, args = [], req = null) {
  return new Promise((resolve, reject) => {
    let actualCmd = cmd;
    let actualArgs = args;
    let isSudo = false;
    let sudoPass = req && req.session ? req.session.sudoPass : null;

    if (cmd === 'sudo') {
      if (!sudoPass) return reject(new Error('Sudo password not set. Please click the lock icon below.'));
      isSudo = true;
      actualArgs = ['-S', ...args];
    }

    const child = execFile(actualCmd, actualArgs, { timeout: 15000, maxBuffer: 1024 * 512 }, (err, stdout, stderr) => {
      if (err) {
        if (stderr && stderr.includes('incorrect password')) {
          if (req && req.session) req.session.sudoPass = null;
          return reject(new Error('Incorrect sudo password.'));
        }
        return reject(new Error(stderr || err.message));
      }
      resolve({ stdout: stdout.trim(), stderr: stderr.trim() });
    });

    if (isSudo) {
      child.stdin.write(sudoPass + '\n');
      child.stdin.end();
    }
  });
}

async function nginxTest(req) {
  return safeExecFile('sudo', ['nginx', '-t'], req);
}

async function nginxReload(req) {
  return safeExecFile('sudo', ['systemctl', 'reload', 'nginx'], req);
}

async function nginxTestAndReload(req) {
  const testResult = await nginxTest(req);
  await nginxReload(req);
  return testResult;
}

async function getNginxSites() {
  try {
    const files = await fs.readdir(NGINX_SITES_AVAILABLE);
    const confFiles = files.filter(f => !f.startsWith('.'));
    const sites = [];

    for (const file of confFiles) {
      const name = file;
      let status = 'Disabled';
      try {
        const enabledPath = path.join(NGINX_SITES_ENABLED, file);
        const stat = await fs.lstat(enabledPath);
        if (stat.isSymbolicLink() || stat.isFile()) status = 'Enabled';
      } catch { /* not enabled */ }

      let portPath = '-';
      let sslEnabled = false;
      try {
        const content = await fs.readFile(path.join(NGINX_SITES_AVAILABLE, file), 'utf8');
        const proxyMatch = content.match(/proxy_pass\s+http:\/\/(?:127\.0\.0\.1|localhost|[^:]+):(\d+)/);
        if (proxyMatch) {
          portPath = `Port ${proxyMatch[1]}`;
        } else {
          const rootMatch = content.match(/root\s+(.*?);/);
          if (rootMatch) portPath = rootMatch[1];
        }

        if (content.includes('ssl_certificate ')) {
          sslEnabled = true;
        }
      } catch { }

      sites.push({ name, status, file, portPath, sslEnabled });
    }
    return sites;
  } catch {
    return [];
  }
}

async function getSiteConfig(name) {
  const safeName = sanitizeFileName(name);
  if (!safeName) throw new Error('Invalid site name');
  const configPath = path.join(NGINX_SITES_AVAILABLE, safeName);
  // Prevent path traversal
  const resolved = path.resolve(configPath);
  if (!resolved.startsWith(path.resolve(NGINX_SITES_AVAILABLE))) {
    throw new Error('Access denied');
  }
  return fs.readFile(resolved, 'utf8');
}

async function saveSiteConfig(name, content) {
  const safeName = sanitizeFileName(name);
  if (!safeName) throw new Error('Invalid site name');
  const safe = sanitizeConfigContent(content);
  if (safe === null) throw new Error('Config contains invalid characters');
  const configPath = path.join(NGINX_SITES_AVAILABLE, safeName);
  const resolved = path.resolve(configPath);
  if (!resolved.startsWith(path.resolve(NGINX_SITES_AVAILABLE))) {
    throw new Error('Access denied');
  }
  await fs.writeFile(resolved, safe, 'utf8');
  return { stdout: 'Config saved', stderr: '' };
}

function generateNginxConfig(domain, portOrPath, ssl = false) {
  let proxyOrRoot = `proxy_pass http://127.0.0.1:${portOrPath};`;
  if (String(portOrPath).startsWith('/')) {
    proxyOrRoot = `root ${portOrPath};\n        index index.html index.htm;`;
  }
  let config = `# Generated by HyPrive OS — ${new Date().toISOString()}
server {
    listen 80;
    server_name ${domain} www.${domain};

    location / {
        ${proxyOrRoot}
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
`;
  if (ssl) {
    config += `
server {
    listen 443 ssl http2;
    server_name ${domain} www.${domain};

    ssl_certificate /etc/letsencrypt/live/${domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${domain}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        ${proxyOrRoot}
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
`;
  }
  return config;
}

// ==================== System Stats (Safe — no shell!) ====================
function getSystemStats() {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;
  const uptime = os.uptime();

  // CPU usage calculation
  let totalIdle = 0, totalTick = 0;
  cpus.forEach(c => {
    for (const type in c.times) totalTick += c.times[type];
    totalIdle += c.times.idle;
  });
  const cpuUsage = Math.round(((totalTick - totalIdle) / totalTick) * 100);

  return {
    cpu: { usage: cpuUsage, cores: cpus.length, model: cpus[0]?.model || 'Unknown' },
    memory: {
      total: totalMem,
      used: usedMem,
      free: freeMem,
      percent: Math.round((usedMem / totalMem) * 100)
    },
    uptime,
    platform: os.platform(),
    hostname: os.hostname(),
    loadavg: os.loadavg(),
  };
}

async function getTopProcesses() {
  if (IS_WINDOWS) {
    try {
      const result = await new Promise((resolve, reject) => {
        execFile('powershell', [
          '-NoProfile', '-Command',
          'Get-Process | Sort-Object -Property CPU -Descending | Select-Object -First 15 Id,ProcessName,@{N="CPU";E={[math]::Round($_.CPU,1)}},@{N="MemMB";E={[math]::Round($_.WorkingSet64/1MB,1)}} | ConvertTo-Json'
        ], { timeout: 10000 }, (err, stdout) => {
          if (err) return reject(err);
          resolve(stdout);
        });
      });
      const parsed = JSON.parse(result);
      return (Array.isArray(parsed) ? parsed : [parsed]).map(p => ({
        pid: p.Id,
        name: p.ProcessName,
        cpu: p.CPU || 0,
        mem: p.MemMB || 0
      }));
    } catch {
      return [];
    }
  }

  // Linux: read from /proc safely
  try {
    const result = await safeExecFile('ps', ['aux', '--sort=-pcpu', '--no-headers']);
    return result.stdout.split('\n').slice(0, 15).map(line => {
      const parts = line.trim().split(/\s+/);
      return {
        pid: parseInt(parts[1]),
        name: parts[10] || parts[0],
        cpu: parseFloat(parts[2]) || 0,
        mem: parseFloat(parts[5]) ? parseFloat((parseFloat(parts[5]) / 1024).toFixed(2)) : 0
      };
    }).filter(p => p.pid);
  } catch {
    return [];
  }
}

// ==================== Cron Management (Safe) ====================
async function getRawCron() {
  try {
    const result = await safeExecFile('crontab', ['-l']);
    return result.stdout;
  } catch {
    return '';
  }
}

async function saveRawCron(crontabText) {
  const tmpFile = path.join(os.tmpdir(), `cron_${Date.now()}`);
  await fs.writeFile(tmpFile, crontabText + '\n');
  try {
    await safeExecFile('crontab', [tmpFile]);
    return { success: true };
  } finally {
    await fs.unlink(tmpFile).catch(() => { });
  }
}

async function getCronLogs() {
  if (process.platform === 'win32') return 'Cron logs not available on Windows.';
  try {
    const result = await safeExecFile('grep', ['CRON', '/var/log/syslog']);
    return result.stdout.split('\n').slice(-100).join('\n');
  } catch {
    try {
      const result2 = await safeExecFile('grep', ['CRON', '/var/log/cron']);
      return result2.stdout.split('\n').slice(-100).join('\n');
    } catch {
      return 'No cron logs found or permission denied.';
    }
  }
}

// ==================== Nginx Status ====================
async function getNginxStatus() {
  try {
    await safeExecFile('systemctl', ['is-active', 'nginx']);
    return { running: true, status: 'active' };
  } catch {
    return { running: false, status: 'inactive' };
  }
}

// ==================== ROUTES ====================

// Landing → Auto OTP
app.get('/', async (req, res) => {
  if (req.session.isAuthenticated) return res.redirect('/dashboard');
  const error = req.session.loginError || null;
  req.session.loginError = null;
  res.render('login', { error, csrfToken: res.locals.csrfToken });
});

app.post('/api/login/verify', verifyCsrf, async (req, res) => {
  const { username, password } = req.body;
  const authPrefs = loadAuthPrefs();
  
  if (username !== authPrefs.adminUser || !bcrypt.compareSync(password, authPrefs.adminPassHash || '')) {
    return res.json({ valid: false, error: 'Invalid username or password' });
  }

  if (authPrefs.twoFactorEnabled) {
    const s = loadSettings().emailConfig || {};
    const autoEmail = s.to || '';
    if (!autoEmail) {
       return res.json({ valid: false, error: '2FA enabled but email not configured. Please disable 2FA via SSH.' });
    }
    const otp = generateOTP();
    otpStore.set(autoEmail, { otp, timestamp: Date.now(), attempts: 0 });
    const sent = await sendOTPEmail(autoEmail, otp);
    if (!sent) {
       return res.json({ valid: false, error: 'Failed to send OTP email.' });
    }
    req.session.pendingEmail = autoEmail;
    req.session.pending2FA = true;
    return res.json({ valid: true, requires2FA: true, email: autoEmail });
  }

  req.session.isAuthenticated = true;
  req.session.userEmail = 'admin';
  res.json({ valid: true, requires2FA: false });
});

// Verify OTP
app.post('/verify-otp', verifyCsrf, (req, res) => {
  const { email, otp } = req.body;
  const stored = otpStore.get(email);
  const isAjax = req.xhr || (req.headers.accept && req.headers.accept.includes('json'));

  if (!stored) {
    if (isAjax) return res.json({ valid: false, error: 'No OTP found. Refresh to request new one.' });
    req.session.otpError = 'No OTP found. Refresh to request new one.';
    return res.redirect('/verify-otp');
  }
  if (Date.now() - stored.timestamp > 5 * 60 * 1000) {
    otpStore.delete(email);
    if (isAjax) return res.json({ valid: false, error: 'OTP expired. Refresh to request new one.' });
    req.session.otpError = 'OTP expired. Refresh to request new one.';
    return res.redirect('/verify-otp');
  }
  if (stored.attempts >= 3) {
    otpStore.delete(email);
    if (isAjax) return res.json({ valid: false, error: 'Too many failed attempts. Refresh to retry.' });
    req.session.otpError = 'Too many failed attempts. Refresh to retry.';
    return res.redirect('/verify-otp');
  }

  if (stored.otp === otp) {
    otpStore.delete(email);
    req.session.isAuthenticated = true;
    req.session.userEmail = email;
    req.session.pending2FA = false;
    if (isAjax) return res.json({ valid: true });
    return res.redirect('/dashboard');
  }

  stored.attempts++;
  if (isAjax) return res.json({ valid: false, error: `Invalid OTP. ${3 - stored.attempts} attempts left.` });
  req.session.otpError = `Invalid OTP. ${3 - stored.attempts} attempts left.`;
  return res.redirect('/verify-otp');
});

// Resend OTP (JSON endpoint)
app.post('/api/resend-otp', otpLimiter, verifyCsrf, async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email required' });

  const otp = generateOTP();
  otpStore.set(email, { otp, timestamp: Date.now(), attempts: 0 });
  const sent = await sendOTPEmail(email, otp);
  res.json({ success: sent, message: sent ? 'OTP resent' : 'Failed to send' });
});

// Dashboard
app.get('/dashboard', requireAuth, async (req, res) => {
  res.locals.hasSudo = !!req.session.sudoPass;
  const settings = loadSettings();
  const authPrefs = loadAuthPrefs();
  try {
    const sites = await getNginxSites();
    res.render('dashboard', {
      sites,
      userEmail: req.session.userEmail,
      isWindows: IS_WINDOWS,
      csrfToken: res.locals.csrfToken,
      cronCmdWhitelist: CRON_CMD_WHITELIST,
      version: pkg.version,
      settings,
      authPrefs,
    });
  } catch (err) {
    res.render('dashboard', {
      sites: [],
      userEmail: req.session.userEmail,
      isWindows: IS_WINDOWS,
      csrfToken: res.locals.csrfToken,
      cronCmdWhitelist: CRON_CMD_WHITELIST,
      version: pkg.version,
      settings,
      authPrefs,
    });
  }
});

// IDE
app.get('/ide', requireAuth, (req, res) => {
  res.locals.hasSudo = !!req.session.sudoPass;
  res.render('ide', { csrfToken: res.locals.csrfToken, userEmail: req.session.userEmail });
});

// ==================== API: System Stats & Power ====================
app.get('/api/system/stats', requireAuth, apiLimiter, async (req, res) => {
  try {
    const [stats, processes, nginxStatus] = await Promise.all([
      getSystemStats(),
      getTopProcesses(),
      getNginxStatus()
    ]);
    res.json({ stats, processes, nginxStatus, domainStatus: domainStatusCache });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get system stats' });
  }
});

app.post('/api/system/reboot', requireAuth, verifyCsrf, async (req, res) => {
  try {
    await safeExecFile('sudo', ['reboot'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to reboot' });
  }
});

app.post('/api/system/shutdown', requireAuth, verifyCsrf, async (req, res) => {
  try {
    await safeExecFile('sudo', ['shutdown', '-h', 'now'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to shutdown' });
  }
});

app.get('/api/system/folders', requireAuth, async (req, res) => {
  try {
    const dir = req.query.dir ? path.resolve(req.query.dir) : '/home';
    const items = await fs.readdir(dir, { withFileTypes: true });
    const folders = items.filter(i => i.isDirectory() && !i.name.startsWith('.')).map(i => i.name).sort();
    // Also return parent directory for navigation
    const parent = path.dirname(dir);
    res.json({ current: dir, parent: dir === parent ? null : parent, folders });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== API: Sites ====================
app.get('/api/sites', requireAuth, apiLimiter, async (req, res) => {
  try {
    const sites = await getNginxSites();
    res.json({ sites });
  } catch {
    res.json({ sites: [] });
  }
});

app.post('/api/sites', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const domain = sanitizeDomain(req.body.domain);
  const port = req.body.port;

  if (!domain) return res.status(400).json({ error: 'Invalid domain name' });
  if (!isValidPortOrPath(port)) return res.status(400).json({ error: 'Invalid port or path' });

  const logs = [];
  try {
    const config = req.body.config || generateNginxConfig(domain, port, false);
    const configPath = path.join(NGINX_SITES_AVAILABLE, domain);
    const resolved = path.resolve(configPath);
    if (!resolved.startsWith(path.resolve(NGINX_SITES_AVAILABLE))) {
      return res.status(400).json({ error: 'Invalid path' });
    }

    logs.push(`[1/4] Writing config to ${resolved}...`);
    await fs.writeFile(resolved, config);
    logs.push('[1/4] ✔ Config file written successfully');

    // Enable site (symlink)
    const enabledPath = path.join(NGINX_SITES_ENABLED, domain);
    logs.push(`[2/4] Creating symlink ${enabledPath}...`);
    try { await fs.unlink(enabledPath); } catch { }
    await fs.symlink(resolved, enabledPath);
    logs.push('[2/4] ✔ Site enabled (symlink created)');

    logs.push('[3/4] Testing nginx configuration...');
    const testResult = await nginxTestAndReload(req);
    logs.push('[3/4] ✔ Nginx test passed & reloaded');
    if (testResult && (testResult.stdout || testResult.stderr)) {
      logs.push((testResult.stdout || '') + (testResult.stderr || ''));
    }

    logs.push('[4/4] ✔ Site is now live!');
    res.json({ success: true, message: 'Site created and enabled', logs });
  } catch (err) {
    logs.push('[✘] Error: ' + (err.message || 'Failed to create site'));
    res.status(500).json({ error: err.message || 'Failed to create site', logs });
  }
});

// Toggle site
app.post('/api/sites/:name/toggle', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const name = sanitizeFileName(req.params.name);
  if (!name) return res.status(400).json({ error: 'Invalid site name' });

  try {
    const availablePath = path.resolve(path.join(NGINX_SITES_AVAILABLE, name));
    const enabledPath = path.resolve(path.join(NGINX_SITES_ENABLED, name));

    if (!availablePath.startsWith(path.resolve(NGINX_SITES_AVAILABLE))) {
      return res.status(400).json({ error: 'Invalid path' });
    }

    await fs.access(availablePath);

    let action;
    try {
      await fs.lstat(enabledPath);
      await fs.unlink(enabledPath);
      action = 'disabled';
    } catch {
      await fs.symlink(availablePath, enabledPath);
      action = 'enabled';
    }

    const testResult = await nginxTestAndReload(req);
    res.json({ success: true, action, testOutput: testResult.stdout || testResult.stderr });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to toggle site' });
  }
});

// Get site config
app.get('/api/sites/:name/config', requireAuth, apiLimiter, async (req, res) => {
  const name = sanitizeFileName(req.params.name);
  if (!name) return res.status(400).json({ error: 'Invalid site name' });

  try {
    const config = await getSiteConfig(name);
    res.json({ config });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to read config' });
  }
});

// Save site config
app.put('/api/sites/:name/config', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const name = sanitizeFileName(req.params.name);
  if (!name) return res.status(400).json({ error: 'Invalid site name' });

  const { config } = req.body;
  if (!config || typeof config !== 'string') return res.status(400).json({ error: 'Config content required' });

  try {
    await saveSiteConfig(name, config);
    const testResult = await nginxTestAndReload(req);
    res.json({ success: true, message: 'Config saved and nginx reloaded', testOutput: (testResult.stdout || '') + (testResult.stderr || '') });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to save config' });
  }
});

// Delete site
app.delete('/api/sites/:name', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const name = sanitizeFileName(req.params.name);
  if (!name) return res.status(400).json({ error: 'Invalid site name' });

  try {
    const availablePath = path.resolve(path.join(NGINX_SITES_AVAILABLE, name));
    const enabledPath = path.resolve(path.join(NGINX_SITES_ENABLED, name));

    if (!availablePath.startsWith(path.resolve(NGINX_SITES_AVAILABLE))) {
      return res.status(400).json({ error: 'Invalid path' });
    }

    try { await fs.unlink(enabledPath); } catch { }
    await fs.unlink(availablePath);

    delete domainStatusCache[name]; // Clear cache on delete
    await nginxTestAndReload(req);
    res.json({ success: true, message: 'Site deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to delete' });
  }
});

// SSL
app.post('/api/sites/:name/ssl', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const name = sanitizeFileName(req.params.name);
  if (!name) return res.status(400).json({ error: 'Invalid site name' });

  try {
    await safeExecFile('sudo', ['certbot', '--nginx', '-d', name, '-d', `www.${name}`, '--non-interactive', '--agree-tos', '--email', `admin@${name}`], req);
    await nginxTestAndReload(req);
    res.json({ success: true, message: `SSL installed for ${name}` });
  } catch (err) {
    res.status(500).json({ error: err.message || 'SSL installation failed' });
  }
});


// ==================== SUDO PASSWORD API ====================
app.post('/api/sudo-password', requireAuth, verifyCsrf, async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });

  req.session.sudoPass = password;
  try {
    await safeExecFile('sudo', ['chown', '-R', 'ayesha:ayesha', '/etc/nginx/sites-available', '/etc/nginx/sites-enabled'], req);
    res.json({ success: true, message: 'Sudo password authenticated' });
  } catch (err) {
    req.session.sudoPass = null;
    res.status(401).json({ error: 'Authentication failed: ' + err.message });
  }
});

// ==================== DNS API ====================
app.get('/api/dns/check', requireAuth, async (req, res) => {
  const domain = req.query.domain;
  if (!domain) return res.status(400).json({ error: 'Domain required' });
  try {
    let aRecords = [];
    let nsRecords = [];
    try { aRecords = await dns.resolve4(domain); } catch (e) { }
    try { nsRecords = await dns.resolveNs(domain); } catch (e) { }
    res.json({ aRecords, nsRecords });
  } catch (err) {
    res.status(500).json({ error: 'DNS lookup failed' });
  }
});

// ==================== API: Cron Jobs ====================
app.get('/api/cron', requireAuth, apiLimiter, async (req, res) => {
  try {
    const jobs = await getCronJobs();
    res.json({ jobs: jobs.map(j => ({ ...j, description: describeCron(j.expression) })) });
  } catch {
    res.json({ jobs: [] });
  }
});

app.get('/api/cron/config', requireAuth, apiLimiter, async (req, res) => {
  const config = await getRawCron();
  res.json({ config });
});

app.put('/api/cron/config', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const { config } = req.body;
  if (typeof config !== 'string') return res.status(400).json({ error: 'Config required' });
  try {
    await saveRawCron(config);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/settings', requireAuth, verifyCsrf, (req, res) => {
  try {
    const { allowedIps, ide_allowed_root, emailConfig, twoFactorEnabled } = req.body;
    
    // IP Security
    if (allowedIps) {
      const prefs = loadSecurityPrefs();
      prefs.allowedIps = allowedIps;
      saveSecurityPrefs(prefs);
    }
    if (ide_allowed_root) {
      const prefs = loadSecurityPrefs();
      prefs.ideAllowedRoot = ide_allowed_root;
      saveSecurityPrefs(prefs);
    }

    // Email Settings
    if (emailConfig) {
      const settings = loadSettings();
      settings.emailConfig = {
        host: emailConfig.host || '',
        port: emailConfig.port || 465,
        secure: emailConfig.secure !== false,
        user: emailConfig.user || '',
        pass: emailConfig.pass || '',
        from: emailConfig.from || '',
        cc: emailConfig.cc || '',
        bcc: emailConfig.bcc || '',
        to: emailConfig.to || ''
      };
      saveSettingsFile(settings);
    }

    // Auth Prefs
    if (typeof twoFactorEnabled !== 'undefined') {
      const auth = loadAuthPrefs();
      auth.twoFactorEnabled = !!twoFactorEnabled;
      saveAuthPrefs(auth);
    }

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get('/api/firewall/status', requireAuth, async (req, res) => {
  try {
    // 1. Check if ufw is installed
    try {
      await safeExecFile('which', ['ufw'], req);
    } catch (err) {
      return res.json({ installed: false, active: false, rules: [] });
    }

    // 2. Check status and rules
    const result = await safeExecFile('sudo', ['ufw', 'status', 'numbered'], req);
    const output = result.stdout.trim();
    
    if (output.includes('Status: inactive')) {
      return res.json({ installed: true, active: false, rules: [] });
    }

    // Parse active rules
    const lines = output.split('\n');
    const rules = [];
    let parsingRules = false;

    for (const line of lines) {
      if (line.includes('--')) { parsingRules = true; continue; }
      if (!parsingRules) continue;
      
      // Match: [ 1] 80/tcp ALLOW IN Anywhere
      const match = line.match(/^\[\s*(\d+)\]\s+(.*?)\s+(ALLOW IN|DENY IN|REJECT IN|LIMIT IN)\s+(.*)$/);
      if (match) {
        rules.push({
          id: match[1],
          port: match[2].trim(),
          action: match[3].trim(),
          from: match[4].trim()
        });
      }
    }

    res.json({ installed: true, active: true, rules });
  } catch (err) {
    console.error('Firewall status error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/firewall/install', requireAuth, verifyCsrf, async (req, res) => {
  try {
    await safeExecFile('sudo', ['apt-get', 'update', '-y', '-q'], req);
    await safeExecFile('sudo', ['apt-get', 'install', '-y', '-q', 'ufw'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/firewall/toggle', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { action } = req.body;
    if (action === 'enable') {
      await safeExecFile('sudo', ['ufw', '--force', 'enable'], req);
    } else if (action === 'disable') {
      await safeExecFile('sudo', ['ufw', 'disable'], req);
    } else {
      return res.status(400).json({ error: 'Invalid action' });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/firewall/rule', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { action, value } = req.body; // action: 'add' or 'delete', value: port/range or rule ID
    
    if (action === 'add') {
      if (!value) return res.status(400).json({ error: 'Port/Range is required' });
      // Sanitize port string
      if (!/^[0-9:\/tcpudp]+$/.test(value)) return res.status(400).json({ error: 'Invalid port format' });
      await safeExecFile('sudo', ['ufw', 'allow', value], req);
    } else if (action === 'delete') {
      if (!value || isNaN(parseInt(value))) return res.status(400).json({ error: 'Valid rule ID is required' });
      // In ufw, deleting by number asks for confirmation unless --force is used
      await safeExecFile('sudo', ['ufw', '--force', 'delete', value], req);
    } else {
      return res.status(400).json({ error: 'Invalid action' });
    }
    // Auto reload ufw
    await safeExecFile('sudo', ['ufw', 'reload'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// IPTABLES FIREWALL ROUTES
// ----------------------------------------------------

app.get('/api/iptables/status', requireAuth, async (req, res) => {
  try {
    // Check if iptables-persistent is installed
    try {
      await safeExecFile('dpkg', ['-l', 'iptables-persistent'], req);
    } catch (err) {
      return res.json({ installed: false, rules: [] });
    }

    // Get rules
    const result = await safeExecFile('sudo', ['iptables', '-L', 'INPUT', '-n', '--line-numbers'], req);
    const output = result.stdout.trim();
    const lines = output.split('\n');
    const rules = [];

    // Skip header lines
    for (let i = 2; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      // Regex to parse iptables output: Num  Target  Prot  Opt  Source  Destination  [Extras/Ports]
      const parts = line.split(/\s+/);
      // Wait, if it's "Chain INPUT (policy ACCEPT)" it doesn't have 6 parts usually, but we skip line 0 and 1.
      // If there are no rules, lines.length might be 2 (just headers). 
      // Ensure we only parse actual rules. If the line doesn't start with a number, skip.
      if (parts.length >= 6 && !isNaN(parseInt(parts[0]))) {
        rules.push({
          id: parts[0],
          target: parts[1],
          protocol: parts[2],
          source: parts[4],
          destination: parts[5],
          opts: parts.slice(6).join(' ')
        });
      }
    }

    res.json({ installed: true, rules });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/iptables/install', requireAuth, verifyCsrf, async (req, res) => {
  try {
    await safeExecFile('sudo', ['apt-get', 'update', '-y', '-q'], req);
    await safeExecFile('sudo', ['apt-get', 'install', '-y', '-q', 'iptables-persistent', 'netfilter-persistent'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/iptables/rule', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { action, value } = req.body;
    
    if (action === 'add') {
      if (!value) return res.status(400).json({ error: 'Port or Range is required' });
      // Input sanitization
      if (!/^[0-9:]+$/.test(value)) return res.status(400).json({ error: 'Invalid port format. Use numbers or ranges like 3000:5999' });
      
      // Defaulting to insert at index 1 (-I INPUT 1) for tcp ports
      await safeExecFile('sudo', ['iptables', '-I', 'INPUT', '1', '-p', 'tcp', '--dport', value, '-j', 'ACCEPT'], req);
    } else if (action === 'delete') {
      if (!value || isNaN(parseInt(value))) return res.status(400).json({ error: 'Valid rule ID is required' });
      await safeExecFile('sudo', ['iptables', '-D', 'INPUT', value], req);
    } else {
      return res.status(400).json({ error: 'Invalid action' });
    }
    
    // Auto-save permanently
    await safeExecFile('sudo', ['netfilter-persistent', 'save'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ----------------------------------------------------
// GIT MANAGEMENT ROUTES
// ----------------------------------------------------

app.get('/api/git/status', requireAuth, async (req, res) => {
  try {
    try {
      await safeExecFile('which', ['git'], req);
    } catch (err) {
      return res.json({ installed: false });
    }

    let version = '';
    try {
      const versionRes = await safeExecFile('git', ['--version'], req);
      version = versionRes.stdout.trim().replace('git version ', '');
    } catch (e) {}

    let name = '';
    let email = '';
    let remote = '';
    
    try {
      const nameRes = await safeExecFile('git', ['config', '--global', 'user.name'], req);
      name = nameRes.stdout.trim();
    } catch (e) {}

    try {
      const emailRes = await safeExecFile('git', ['config', '--global', 'user.email'], req);
      email = emailRes.stdout.trim();
    } catch (e) {}

    try {
      const remoteRes = await safeExecFile('git', ['remote', 'get-url', 'origin'], req);
      remote = remoteRes.stdout.trim();
    } catch (e) {}

    let sshKey = null;
    try {
      const os = require('os');
      const homeDir = os.homedir();
      const ed25519Path = path.join(homeDir, '.ssh', 'id_ed25519.pub');
      const rsaPath = path.join(homeDir, '.ssh', 'id_rsa.pub');
      
      if (fsSync.existsSync(ed25519Path)) {
        sshKey = fsSync.readFileSync(ed25519Path, 'utf8').trim();
      } else if (fsSync.existsSync(rsaPath)) {
        sshKey = fsSync.readFileSync(rsaPath, 'utf8').trim();
      }
    } catch (e) {}

    res.json({ installed: true, version, name, email, remote, sshKey });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/install', requireAuth, verifyCsrf, async (req, res) => {
  try {
    await safeExecFile('sudo', ['apt-get', 'update', '-y', '-q'], req);
    await safeExecFile('sudo', ['apt-get', 'install', '-y', '-q', 'git'], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/config', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { name, email } = req.body;
    if (name) await safeExecFile('git', ['config', '--global', 'user.name', name], req);
    if (email) await safeExecFile('git', ['config', '--global', 'user.email', email], req);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/remote', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { action, url } = req.body;
    if (action === 'add') {
      if (!url) return res.status(400).json({ error: 'URL required' });
      try {
        await safeExecFile('git', ['remote', 'remove', 'origin'], req);
      } catch(e) {}
      await safeExecFile('git', ['remote', 'add', 'origin', url], req);
    } else if (action === 'remove') {
      try {
        await safeExecFile('git', ['remote', 'remove', 'origin'], req);
      } catch(e) {}
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/ssh-key', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required for SSH key' });
    
    const os = require('os');
    const homeDir = os.homedir();
    const ed25519Path = path.join(homeDir, '.ssh', 'id_ed25519');
    const rsaPath = path.join(homeDir, '.ssh', 'id_rsa');
    
    let supportsEd25519 = false;
    try {
      const { stdout } = await safeExecFile('ssh', ['-Q', 'key'], req);
      supportsEd25519 = stdout.includes('ed25519');
    } catch (e) {}
    
    let keyPath = '';
    if (supportsEd25519) {
      if (!fsSync.existsSync(ed25519Path)) {
        await safeExecFile('ssh-keygen', ['-t', 'ed25519', '-C', email, '-N', '', '-f', ed25519Path], req);
      }
      keyPath = ed25519Path + '.pub';
    } else {
      if (!fsSync.existsSync(rsaPath)) {
        await safeExecFile('ssh-keygen', ['-t', 'rsa', '-b', '4096', '-C', email, '-N', '', '-f', rsaPath], req);
      }
      keyPath = rsaPath + '.pub';
    }
    
    const sshKey = fsSync.readFileSync(keyPath, 'utf8').trim();
    res.json({ success: true, sshKey });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/git/test-ssh', requireAuth, verifyCsrf, async (req, res) => {
  try {
    try {
      await safeExecFile('ssh', ['-T', '-o', 'StrictHostKeyChecking=no', 'git@github.com'], req);
      res.json({ success: true, message: 'Successfully authenticated' });
    } catch (error) {
      if (error.stderr && error.stderr.includes('successfully authenticated')) {
        return res.json({ success: true, message: error.stderr });
      }
      return res.status(400).json({ success: false, error: error.stderr || error.message });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/cron/logs', requireAuth, apiLimiter, async (req, res) => {
  const logs = await getCronLogs();
  res.json({ logs });
});

app.post('/api/cron/test', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const { url, method } = req.body;
  if (!url || !url.startsWith('http')) {
    return res.status(400).json({ error: 'Invalid URL. Must start with http:// or https://' });
  }
  const safeMethod = ['GET', 'POST'].includes(method) ? method : 'GET';
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    const start = Date.now();
    const response = await fetch(url, { method: safeMethod, signal: controller.signal });
    const text = await response.text();
    clearTimeout(timeoutId);
    
    res.json({ 
      success: true, 
      status: response.status, 
      timeMs: Date.now() - start,
      response: text.substring(0, 5000) // Limit response size 
    });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ==================== API: Nginx Status ====================
app.get('/api/nginx/status', requireAuth, apiLimiter, async (req, res) => {
  try {
    const status = await getNginxStatus();
    res.json(status);
  } catch {
    res.json({ running: false, status: 'unknown' });
  }
});

app.post('/api/nginx/reload', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  try {
    const testResult = await nginxTestAndReload(req);
    res.json({ success: true, message: 'Nginx tested and reloaded successfully', testOutput: testResult.stdout || testResult.stderr });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Nginx test/reload failed' });
  }
});

// ==================== API: PM2 Management ====================
app.get('/api/pm2', requireAuth, apiLimiter, async (req, res) => {
  try {
    const result = await safeExecFile('pm2', ['jlist']);
    const list = JSON.parse(result.stdout);
    res.json({ processes: list });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch PM2 list' });
  }
});

app.post('/api/pm2/:name/:action', requireAuth, apiLimiter, verifyCsrf, async (req, res) => {
  const { name, action } = req.params;
  if (!['start', 'stop', 'restart', 'flush'].includes(action)) {
    return res.status(400).json({ error: 'Invalid action' });
  }
  if (!/^[\w\.-]+$/.test(name) && name !== 'all') {
    return res.status(400).json({ error: 'Invalid process name' });
  }
  try {
    await safeExecFile('pm2', [action, name]);
    res.json({ success: true, message: `Successfully executed ${action} on ${name}` });
  } catch (err) {
    res.status(500).json({ error: err.message || `Failed to ${action} process` });
  }
});

app.get('/api/pm2/:name/logs', requireAuth, apiLimiter, async (req, res) => {
  const { name } = req.params;
  const lines = req.query.lines || '100';
  if (!/^[\w\.-]+$/.test(name) && name !== 'all') {
    return res.status(400).json({ error: 'Invalid process name' });
  }
  if (!/^\d+$/.test(lines)) {
    return res.status(400).json({ error: 'Invalid lines parameter' });
  }
  try {
    const result = await safeExecFile('pm2', ['logs', name, '--lines', lines, '--nostream']);
    res.json({ logs: result.stdout || result.stderr || 'No logs available.' });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to fetch logs' });
  }
});


app.post('/api/pm2/global/:action', requireAuth, verifyCsrf, async (req, res) => {
  const action = req.params.action;
  if (!['save', 'resurrect', 'restartAll', 'stopAll', 'flush'].includes(action)) return res.status(400).json({ error: 'Invalid action' });
  try {
    let args = [action];
    if (action === 'restartAll') args = ['restart', 'all'];
    else if (action === 'stopAll') args = ['stop', 'all'];
    await safeExecFile('pm2', args);
    res.json({ success: true, message: `PM2 ${action} successful` });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/pm2/backup-json', requireAuth, async (req, res) => {
  try {
    const result = await safeExecFile('pm2', ['jlist']);
    const list = JSON.parse(result.stdout);
    res.setHeader('Content-disposition', 'attachment; filename=pm2_backup.json');
    res.setHeader('Content-type', 'application/json');
    res.send(JSON.stringify(list, null, 2));
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate PM2 backup' });
  }
});

app.get('/api/pm2/backup-info', requireAuth, async (req, res) => {
  try {
    const home = os.homedir();
    const dumpPath = path.join(home, '.pm2', 'dump.pm2');
    const stat = await fs.stat(dumpPath);
    res.json({ lastBackup: stat.mtime });
  } catch {
    res.json({ lastBackup: null });
  }
});

// ==================== API: IDE Management ====================
app.get('/api/ide/files', requireAuth, async (req, res) => {
  try {
    let dir = req.query.dir;
    if (typeof dir !== 'string' || dir.trim() === '') {
      dir = getIdeAllowedRoot();
    } else {
      dir = path.resolve(dir);
    }
    if (!isSafeIdePath(dir)) return res.status(403).json({ error: 'Access denied outside allowed root' });

    const items = await fs.readdir(dir, { withFileTypes: true });
    const files = items.map(i => ({
      name: i.name,
      isDirectory: i.isDirectory(),
      path: path.join(dir, i.name)
    })).sort((a, b) => b.isDirectory - a.isDirectory || a.name.localeCompare(b.name));
    res.json({ currentDir: dir, files });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/ide/file', requireAuth, async (req, res) => {
  try {
    const filePath = path.resolve(req.query.path);
    if (!isSafeIdePath(filePath)) return res.status(403).json({ error: 'Access denied' });

    const content = await fs.readFile(filePath, 'utf8');
    res.json({ content });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/ide/file', requireAuth, verifyCsrf, express.json({ limit: '10mb' }), async (req, res) => {
  try {
    const filePath = path.resolve(req.query.path);
    if (!isSafeIdePath(filePath)) return res.status(403).json({ error: 'Access denied' });

    await fs.writeFile(filePath, req.body.content, 'utf8');
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/ide/file', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const filePath = path.resolve(req.query.path);
    if (!isSafeIdePath(filePath)) return res.status(403).json({ error: 'Access denied' });
    const stats = await fs.stat(filePath);
    if (stats.isDirectory()) {
      return res.status(400).json({ error: 'Cannot delete directories' });
    }
    await fs.unlink(filePath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ide/rename', requireAuth, verifyCsrf, express.json(), async (req, res) => {
  try {
    const oldPath = path.resolve(req.body.oldPath);
    const newPath = path.resolve(req.body.newPath);
    if (!isSafeIdePath(oldPath) || !isSafeIdePath(newPath)) return res.status(403).json({ error: 'Access denied' });
    await fs.rename(oldPath, newPath);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ide/permissions', requireAuth, verifyCsrf, async (req, res) => {
  const { path: targetPath, mode } = req.body;
  if (!targetPath || !mode || !/^[0-7]{3,4}$/.test(mode)) {
    return res.status(400).json({ error: 'Invalid path or mode' });
  }
  try {
    const fullPath = path.resolve(targetPath);
    if (!fullPath.startsWith('/')) {
      return res.status(400).json({ error: 'Invalid path' });
    }
    // We use safeExecFile with 'sudo' since we might need elevated permissions
    // Wait, the ide currently doesn't run with sudo by default unless using the command runner.
    // The user specifically requested a button. Let's just run chmod recursively.
    await safeExecFile('chmod', ['-R', mode, fullPath]);
    res.json({ success: true, message: `Permissions updated to ${mode}` });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Failed to change permissions' });
  }
});

// Git Status Check
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

app.get('/api/ide/git-status', requireAuth, async (req, res) => {
  try {
    let installed = false;
    let version = '';
    let user = null;
    let email = null;
    let isRepo = false;
    
    try {
      const { stdout } = await execPromise('git --version');
      if (stdout) {
        installed = true;
        version = stdout.trim();
      }
    } catch(e) {}
    
    if (installed) {
      try {
        const { stdout: repoOut } = await execPromise('git rev-parse --is-inside-work-tree', { cwd: getIdeAllowedRoot() });
        isRepo = repoOut.trim() === 'true';
      } catch(e) {
        isRepo = false;
      }
      try {
        const { stdout: uOut } = await execPromise('git config --global user.name');
        user = uOut.trim();
      } catch(e) {}
      try {
        const { stdout: eOut } = await execPromise('git config --global user.email');
        email = eOut.trim();
      } catch(e) {}
    }
    
    res.json({ installed, isRepo, version, account: { name: user, email: email } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ide/command', requireAuth, verifyCsrf, async (req, res) => {
  const { cmd, args, cwd } = req.body;
  const taskId = crypto.randomUUID();

  if (!['npm', 'pm2', 'rm', 'custom', 'git'].includes(cmd)) {
    return res.status(403).json({ error: 'Command not allowed' });
  }

  const workDir = (cwd && typeof cwd === 'string' && cwd.trim() !== '') ? path.resolve(cwd) : getIdeAllowedRoot();
  if (!isSafeIdePath(workDir)) {
    return res.status(403).json({ error: 'Access denied to directory' });
  }

  const safeArgs = args || [];
  let isAllowed = false;

  if (cmd === 'npm') {
    const joined = safeArgs.join(' ');
    if (joined === 'install' || joined === 'audit' || joined === 'install --legacy-peer-deps' || joined === 'run build') {
      isAllowed = true;
    }
  } else if (cmd === 'pm2') {
    if (safeArgs.length === 4 && safeArgs[0] === 'start' && safeArgs[2] === '--name') {
      const entryPoint = safeArgs[1];
      const appName = safeArgs[3];
      if (/^[\w./-]+$/.test(entryPoint) && /\.(js|ts|json|sh)$/i.test(entryPoint) && /^[\w.-]+$/.test(appName)) {
        try {
          await fs.access(path.join(workDir, entryPoint));
          isAllowed = true;
        } catch {
          return res.status(400).json({ error: 'Entry point file does not exist in the selected directory' });
        }
      }
    }
  } else if (cmd === 'rm') {
    if (safeArgs.length === 2 && safeArgs[0] === '-rf' && safeArgs[1] === 'node_modules') {
      isAllowed = true;
    }
  } else if (cmd === 'custom') {
    isAllowed = true;
  } else if (cmd === 'git') {
    isAllowed = true; // Allow all git subcommands (clone, status, push, etc)
  }

  if (!isAllowed) {
    return res.status(403).json({ error: 'Arguments not allowed or malformed' });
  }

  const childEnv = { ...process.env };
  delete childEnv.PORT; // Prevent port clash with current app

  const commandStr = cmd === 'custom' ? safeArgs.join(' ') : `${cmd} ${safeArgs.join(' ')}`;

  let child;
  if (cmd === 'custom') {
    child = spawn('bash', ['-c', safeArgs.join(' ')], { cwd: workDir, env: childEnv });
  } else {
    child = spawn(cmd, safeArgs, { cwd: workDir, env: childEnv });
  }
  activeTasks.set(taskId, { process: child, logs: [] });

  // Track process in history
  const history = loadProcessHistory();
  history.push({
    id: taskId,
    command: commandStr,
    cwd: workDir,
    startTime: new Date().toISOString(),
    status: 'running',
    exitCode: null,
    endTime: null
  });
  saveProcessHistory(history);

  child.stdout.on('data', (data) => {
    const task = activeTasks.get(taskId);
    if (task) task.logs.push(data.toString());
    appendProcessLog(taskId, data.toString());
  });

  child.stderr.on('data', (data) => {
    const task = activeTasks.get(taskId);
    if (task) task.logs.push(data.toString());
    appendProcessLog(taskId, data.toString());
  });

  child.on('close', (code) => {
    const task = activeTasks.get(taskId);
    if (task) task.logs.push(`\n[Process exited with code ${code}]\n`);
    appendProcessLog(taskId, `\n[Process exited with code ${code}]\n`);

    // Update process history
    const hist = loadProcessHistory();
    const entry = hist.find(h => h.id === taskId);
    if (entry) {
      entry.status = code === 0 ? 'completed' : 'failed';
      entry.exitCode = code;
      entry.endTime = new Date().toISOString();
      saveProcessHistory(hist);
    }
  });

  res.json({ taskId });
});

app.post('/api/ide/kill/:taskId', requireAuth, verifyCsrf, (req, res) => {
  const taskId = req.params.taskId;
  const task = activeTasks.get(taskId);
  if (!task) {
    return res.status(404).json({ error: 'Task not found or already finished' });
  }
  try {
    task.process.kill('SIGINT'); // Graceful kill
    res.json({ success: true, message: 'Stop signal sent' });
  } catch (e) {
    res.status(500).json({ error: 'Failed to kill process' });
  }
});

app.get('/api/ide/logs/:taskId', requireAuth, (req, res) => {
  const taskId = req.params.taskId;
  const task = activeTasks.get(taskId);

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');

  if (!task) {
    res.write(`data: ${JSON.stringify('[Task not found or finished]')}\n\n`);
    return res.end();
  }

  res.flushHeaders(); // Ensure headers are sent immediately

  task.logs.forEach(log => {
    res.write(`data: ${JSON.stringify(log)}\n\n`);
  });
  task.logs = [];

  const onData = (data) => {
    res.write(`data: ${JSON.stringify(data.toString())}\n\n`);
  };

  task.process.stdout.on('data', onData);
  task.process.stderr.on('data', onData);

  task.process.on('close', () => {
    res.write(`data: ${JSON.stringify('\\n[Task finished]\\n')}\n\n`);
    res.end();
    activeTasks.delete(taskId);
  });

  req.on('close', () => {
    task.process.stdout.off('data', onData);
    task.process.stderr.off('data', onData);
  });
});

// ==================== API: Notification Preferences ====================
app.get('/api/notifications/prefs', requireAuth, (req, res) => {
  const prefs = loadNotifPrefs();
  res.json({ prefs });
});

app.put('/api/notifications/prefs', requireAuth, verifyCsrf, (req, res) => {
  const { domain, enabled } = req.body;
  if (!domain || typeof enabled !== 'boolean') {
    return res.status(400).json({ error: 'domain and enabled (boolean) required' });
  }
  const prefs = loadNotifPrefs();
  prefs[domain] = enabled;
  saveNotifPrefs(prefs);
  res.json({ success: true, prefs });
});

// ==================== API: Security Settings ====================
app.get('/api/settings', requireAuth, (req, res) => {
  const prefs = loadSecurityPrefs();
  res.json({ settings: prefs });
});

// ==================== API: IDE File Download ====================
app.get('/api/ide/download', requireAuth, async (req, res) => {
  try {
    const filePath = path.resolve(req.query.path);
    if (!isSafeIdePath(filePath)) return res.status(403).json({ error: 'Access denied' });

    const stat = await fs.stat(filePath);
    if (!stat.isFile()) return res.status(400).json({ error: 'Not a file' });

    res.download(filePath);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/ide/download-zip', requireAuth, async (req, res) => {
  try {
    const dirPath = path.resolve(req.query.path);
    if (!isSafeIdePath(dirPath)) return res.status(403).json({ error: 'Access denied' });

    const stat = await fs.stat(dirPath);
    if (!stat.isDirectory()) return res.status(400).json({ error: 'Not a directory' });

    const folderName = path.basename(dirPath);
    res.setHeader('Content-disposition', `attachment; filename=${folderName}.zip`);
    res.setHeader('Content-type', 'application/zip');

    const archive = archiver('zip', { zlib: { level: 6 } });
    archive.on('error', (err) => { 
      if (!res.headersSent) {
        res.status(500).json({ error: err.message });
      } else {
        console.error('Archiver error:', err);
        res.end();
      }
    });
    archive.pipe(res);
    archive.directory(dirPath, folderName);
    archive.finalize();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== API: IDE File Upload ====================
const upload = multer({
  dest: path.join(os.tmpdir(), 'nginx-manager-uploads'),
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB max
});

app.post('/api/ide/upload', requireAuth, upload.array('files', 50), async (req, res) => {
  try {
    const targetDir = (req.body.targetDir && typeof req.body.targetDir === 'string' && req.body.targetDir.trim() !== '') ? path.resolve(req.body.targetDir) : getIdeAllowedRoot();
    if (!isSafeIdePath(targetDir)) {
      // Clean up uploaded temp files
      for (const f of req.files) { await fs.unlink(f.path).catch(() => {}); }
      return res.status(403).json({ error: 'Access denied' });
    }

    // Ensure target directory exists
    await fs.mkdir(targetDir, { recursive: true });

    const results = [];
    for (const file of req.files) {
      const originalName = file.originalname;
      // Handle nested folder paths from webkitdirectory
      const relativePath = req.body[`relativePath_${file.fieldname}_${results.length}`] || originalName;
      
      // PREVENT PATH TRAVERSAL
      // Ensure the relative path does not navigate out of the target directory
      const destPath = path.resolve(path.join(targetDir, relativePath));
      if (!isSafeIdePath(destPath) || !destPath.startsWith(path.resolve(targetDir) + path.sep)) {
        await fs.unlink(file.path).catch(() => {});
        continue; // Skip unsafe files
      }
      
      const destDir = path.dirname(destPath);

      // Ensure destination subdirectory exists
      await fs.mkdir(destDir, { recursive: true });

      // Move file from temp to destination
      const content = await fs.readFile(file.path);
      await fs.writeFile(destPath, content);
      await fs.unlink(file.path).catch(() => {});

      results.push({ name: originalName, size: file.size, path: destPath });
    }

    res.json({ success: true, files: results, count: results.length });
  } catch (err) {
    // Clean up on error
    if (req.files) {
      for (const f of req.files) { await fs.unlink(f.path).catch(() => {}); }
    }
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/ide/extract', requireAuth, verifyCsrf, async (req, res) => {
  try {
    const { zipPath, targetDir } = req.body;
    const resolvedZip = path.resolve(zipPath);
    const resolvedTarget = targetDir ? path.resolve(targetDir) : path.dirname(resolvedZip);

    if (!isSafeIdePath(resolvedZip) || !isSafeIdePath(resolvedTarget)) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const zip = new AdmZip(resolvedZip);
    zip.extractAllTo(resolvedTarget, true);
    res.json({ success: true, message: 'ZIP extracted successfully', target: resolvedTarget });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== API: IDE Process History ====================
app.get('/api/ide/process-history', requireAuth, (req, res) => {
  const history = loadProcessHistory();
  // Check if any "running" processes are actually still active
  for (const entry of history) {
    if (entry.status === 'running' && !activeTasks.has(entry.id)) {
      entry.status = 'unknown';
    }
  }
  res.json({ history: history.reverse() }); // Most recent first
});

app.get('/api/ide/process-log/:taskId', requireAuth, async (req, res) => {
  try {
    const taskId = req.params.taskId;
    // Validate taskId format (UUID)
    if (!/^[a-f0-9-]{36}$/.test(taskId)) {
      return res.status(400).json({ error: 'Invalid task ID' });
    }
    const logFile = path.join(PROCESS_LOGS_DIR, `${taskId}.log`);
    const content = await fs.readFile(logFile, 'utf8');
    res.json({ log: content });
  } catch (err) {
    res.json({ log: 'No logs found for this process.' });
  }
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

// 404 Catch-all
app.use((req, res) => {
  res.redirect('/');
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

// ==================== DOMAIN MONITORING ====================
async function monitorDomains() {
  try {
    const sites = await getNginxSites();
    const enabledSites = sites.filter(s => s.status === 'Enabled' && s.name !== 'default');
    const notifPrefs = loadNotifPrefs();

    for (const site of enabledSites) {
      const domain = site.name;
      let isLive = false;
      try {
        // Attempt HTTP request. timeout is 15s to reduce false positives for slow initial loads
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const res = await fetch(`http://${domain}`, { signal: controller.signal, redirect: 'follow' });
        clearTimeout(timeoutId);

        isLive = res.status > 0; // If we get ANY response from the server, it's alive (even 502 means Nginx is up)
      } catch (err) {
        isLive = false;
      }

      const prevStatus = domainStatusCache[domain];
      domainStatusCache[domain] = isLive ? 'UP' : 'DOWN';

      // Send alert only if:
      // 1. Status actually changed from previous known state
      // 2. Notification is enabled for this domain
      // 3. Cooldown period has passed (5 minutes)
      if (prevStatus !== undefined && prevStatus !== domainStatusCache[domain]) {
        const isNotifEnabled = notifPrefs[domain] === true;
        const lastAlert = lastAlertTime.get(domain) || 0;
        const now = Date.now();

        if (isNotifEnabled && (now - lastAlert) >= ALERT_COOLDOWN_MS) {
          await sendDomainAlertEmail(domain, isLive);
          lastAlertTime.set(domain, now);
        } else if (!isNotifEnabled) {
          // Silently skip — notification disabled for this domain
        } else {
          console.log(`⏳ Cooldown active for ${domain} — skipping alert (${Math.round((ALERT_COOLDOWN_MS - (now - lastAlert)) / 1000)}s remaining)`);
        }
      }
    }
  } catch (err) {
    console.error('❌ Domain monitoring error:', err.message);
  }
}

// Start monitoring every 60 seconds
setInterval(monitorDomains, 60000);
// Initial check immediately
setTimeout(monitorDomains, 2000);

// Start server with Socket.IO
const server = require('http').createServer(app);
const { Server } = require('socket.io');
const io = new Server(server, { cors: { origin: '*' } });

// Session middleware wrapping for socket.io
const sharedSession = require('express-socket.io-session');
// We can use the existing sessionMiddleware
io.use(sharedSession(sessionMiddleware, { autoSave: true }));

io.on('connection', (socket) => {
  if (!socket.handshake.session || !socket.handshake.session.isAuthenticated) {
    socket.disconnect();
    return;
  }

  // ── Web SSH (Fallback) ────────────────
  const { spawn } = require('child_process');
  let bashPty = spawn('python3', ['-u', '-c', 'import pty; pty.spawn("/bin/bash")'], {
    env: { ...process.env, TERM: 'xterm-256color' },
    cwd: process.cwd()
  });

  bashPty.stdout.on('data', (data) => {
    socket.emit('output', data.toString());
  });

  bashPty.stderr.on('data', (data) => {
    socket.emit('output', data.toString());
  });

  socket.on('input', (data) => {
    bashPty.stdin.write(data);
  });

  // ── Interactive SSL Terminal ──────────
  let sslPty = null;
  socket.on('start-ssl', (data) => {
    const sudoPass = socket.handshake.session ? socket.handshake.session.sudoPass : null;
    if (!sudoPass) {
      socket.emit('ssl-output', 'ERROR: Sudo password not set. Please set it using the lock icon in the dashboard.\r\n');
      return;
    }

    // Support both old string format and new {domain, domains} format
    let domains = [];
    if (typeof data === 'string') {
      domains = [data, `www.${data}`];
    } else if (data && data.domains && data.domains.length) {
      domains = data.domains;
    }
    if (domains.length === 0) {
      socket.emit('ssl-output', 'ERROR: No domains selected.\r\n');
      return;
    }

    const domainArgs = domains.flatMap(d => ['-d', d]);
    socket.emit('ssl-output', `Starting SSL installation for: ${domains.join(', ')}...\r\n`);
    sslPty = spawn('sudo', ['-S', 'certbot', '--nginx', ...domainArgs]);

    sslPty.stdin.write(sudoPass + '\n');

    sslPty.stdout.on('data', (data) => {
        socket.emit('ssl-output', data.toString());
      });
    sslPty.stderr.on('data', (data) => {
      socket.emit('ssl-output', data.toString());
    });
    sslPty.on('close', (code) => {
      socket.emit('ssl-output', `\r\n[Process exited with code ${code}]\r\n`);
    });
  });

  socket.on('ssl-input', (data) => {
    if (sslPty) sslPty.stdin.write(data);
  });

  socket.on('disconnect', () => {
    if (bashPty) bashPty.kill();
    if (sslPty) sslPty.kill();
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 HyPrive OS → http://0.0.0.0:${PORT} `);
  const s = loadSettings().emailConfig || {};
  if (s.user) console.log(`📧 SMTP: ${s.user}`);
  else console.log(`📧 SMTP: Not configured (Set up in UI)`);
  console.log(`💻 Platform: ${process.platform}`);
});