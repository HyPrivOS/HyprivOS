    // Logo fallback
    const sLogo = document.getElementById('sidebarLogo');
    if (sLogo) sLogo.addEventListener('error', () => sLogo.style.display = 'none');
    const CSRF = '';
    let currentEditDomain = '';
    let pendingDeleteDomain = '';
    let notifPrefs = {};

    // ── Panel Switching ──────────────────────────
    function switchPanel(name) {
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      const panel = document.getElementById('panel-' + name);
      const nav = document.querySelector(`.nav-item[data-panel="${name}"]`);
      if (panel) panel.classList.add('active');
      if (nav) nav.classList.add('active');
      // Close mobile sidebar
      document.getElementById('sidebar').classList.remove('open');
      document.getElementById('sidebarOverlay').classList.remove('active');
      // Load data for specific panels
      if (name === 'cron') loadCronJobs();
      if (name === 'settings') loadSettings();
      if (name === 'sites') refreshSites();
      if (name === 'pm2') refreshPM2();
      if (name === 'ssh') {
        initTerminal();
        if (term) setTimeout(() => term.focus(), 200);
      }
    }

    // ── Sidebar Toggle (mobile) ──────────────────
    function toggleSidebar() {
      const sb = document.getElementById('sidebar');
      const ov = document.getElementById('sidebarOverlay');
      sb.classList.toggle('open');
      ov.classList.toggle('active');
    }

    // ── Toast ────────────────────────────────────
    function showToast(msg, type = 'success') {
      const t = document.createElement('div');
      t.className = `toast toast-${type}`;
      const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'exclamation-triangle';
      t.innerHTML = `<i class="fas fa-${icon}"></i> <span>${msg}</span>`;
      document.getElementById('toasts').appendChild(t);
      setTimeout(() => { t.style.animation = 'toast-out 0.3s ease forwards'; setTimeout(() => t.remove(), 300); }, 3500);
    }

    // ── Modal ────────────────────────────────────
    function openModal(id) { document.getElementById(id).classList.add('active'); }
    function closeModal(id) { document.getElementById(id).classList.remove('active'); }

    // ── Format Helpers ───────────────────────────
    function fmtBytes(b) {
      if (b < 1024) return b + ' B';
      if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
      if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB';
      return (b / 1073741824).toFixed(1) + ' GB';
    }
    function fmtUptime(s) {
      const d = Math.floor(s / 86400);
      const h = Math.floor((s % 86400) / 3600);
      const m = Math.floor((s % 3600) / 60);
      if (d > 0) return `${d}d ${h}h`;
      if (h > 0) return `${h}h ${m}m`;
      return `${m}m`;
    }
    function escapeHtml(str) {
      const d = document.createElement('div');
      d.textContent = str;
      return d.innerHTML;
    }

    // ── Notification Preferences ─────────────────
    async function loadNotifPrefs() {
      try {
        const r = await fetch('/api/notifications/prefs');
        const d = await r.json();
        notifPrefs = d.prefs || {};
      } catch(e) { notifPrefs = {}; }
    }

    async function toggleNotif(domain, enabled) {
      try {
        await fetch('/api/notifications/prefs', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ domain, enabled })
        });
        notifPrefs[domain] = enabled;
        showToast(`Notifications ${enabled ? 'enabled' : 'disabled'} for ${domain}`, 'success');
      } catch(e) {
        showToast('Failed to update notification preference', 'error');
      }
    }

    // ── System Stats ─────────────────────────────
    async function loadStats() {
      try {
        const resp = await fetch('/api/system/stats');
        const data = await resp.json();

        // CPU
        document.getElementById('cpuVal').textContent = data.stats.cpu.usage + '%';
        document.getElementById('cpuModel').textContent = data.stats.cpu.cores + ' cores';
        document.getElementById('cpuBar').style.width = data.stats.cpu.usage + '%';
        const cpuBar = document.getElementById('cpuBar');
        cpuBar.className = 'stat-bar-fill ' + (data.stats.cpu.usage > 80 ? 'danger' : data.stats.cpu.usage > 50 ? 'warning' : 'primary');

        // Memory
        const memPct = data.stats.memory.percent;
        document.getElementById('memVal').textContent = memPct + '%';
        document.getElementById('memDetail').textContent = fmtBytes(data.stats.memory.used) + ' / ' + fmtBytes(data.stats.memory.total);
        document.getElementById('memBar').style.width = memPct + '%';
        const memBar = document.getElementById('memBar');
        memBar.className = 'stat-bar-fill ' + (memPct > 80 ? 'danger' : memPct > 50 ? 'warning' : 'success');

        // Uptime
        document.getElementById('uptimeVal').textContent = fmtUptime(data.stats.uptime);
        document.getElementById('hostInfo').textContent = data.stats.hostname + ' · ' + data.stats.platform;

        // Nginx status
        const nBadge = document.getElementById('nginxStatusBadge');
        if (data.nginxStatus.running) {
          nBadge.innerHTML = '<span class="nginx-status running"><span class="dot"></span> Running</span>';
        } else {
          nBadge.innerHTML = '<span class="nginx-status stopped"><span class="dot"></span> ' + escapeHtml(data.nginxStatus.status) + '</span>';
        }

        // Processes
        const tbody = document.getElementById('processTable');
        if (data.processes.length === 0) {
          tbody.innerHTML = '<tr><td colspan="4" class="empty-state" style="padding:16px"><i class="fas fa-ghost"></i><p>No processes</p></td></tr>';
        } else {
          tbody.innerHTML = data.processes.map(p => {
            const cpuColor = p.cpu > 50 ? 'var(--danger)' : p.cpu > 20 ? 'var(--warning)' : p.cpu > 5 ? 'orange' : 'var(--success)';
            const memColor = p.mem > 500 ? 'var(--danger)' : p.mem > 200 ? 'var(--warning)' : 'var(--success)';
            return `
            <tr class="process-row">
              <td class="pid">${p.pid}</td>
              <td>${escapeHtml(String(p.name))}</td>
              <td style="color:${cpuColor}; font-weight:bold">${p.cpu.toFixed(1)}%</td>
              <td style="color:${memColor}; font-weight:bold">${typeof p.mem === 'number' && p.mem < 100 ? p.mem.toFixed(1) : p.mem}</td>
            </tr>`;
          }).join('');
        }

        // Domain Status Update with grouping and sorting
        if (data.domainStatus) {
          const dsList = document.getElementById('domainStatusList');
          const domains = Object.keys(data.domainStatus);
          if (domains.length === 0) {
            dsList.innerHTML = '<div class="empty-state" style="padding:20px 10px"><i class="fas fa-satellite"></i><p>No active domains</p></div>';
          } else {
            domains.sort((a, b) => a.localeCompare(b));
            
            const online = domains.filter(d => data.domainStatus[d] === 'UP');
            const offline = domains.filter(d => data.domainStatus[d] !== 'UP');
            
            const buildRow = (domain, isUp) => {
              const sClass = isUp ? 'up' : 'down';
              const sText = isUp ? 'Live' : 'Stopped';
              const isNotifOn = notifPrefs[domain] === true;
              return `
              <div class="domain-status-item">
                <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
                  <div class="d-name" title="${escapeHtml(domain)}">${escapeHtml(domain)}</div>
                </div>
                <div style="display:flex;align-items:center;gap:10px;">
                  <div class="domain-status-indicator ${sClass}">
                    <div class="dot"></div>
                    <span>${sText}</span>
                  </div>
                  <label class="notif-toggle" title="${isNotifOn ? 'Notifications ON' : 'Notifications OFF'}">
                    <input type="checkbox" ${isNotifOn ? 'checked' : ''} onchange="toggleNotif('${escapeHtml(domain)}', this.checked)">
                    <span class="notif-slider"></span>
                  </label>
                </div>
              </div>`;
            };
            
            let html = '';
            
            if (online.length) {
              html += `<div style="font-size:11px; font-weight:600; color:var(--success); padding:8px; cursor:pointer; background:rgba(16,185,129,0.1); border-radius:4px; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center;" onclick="document.getElementById('grp-online').style.display = document.getElementById('grp-online').style.display === 'none' ? 'block' : 'none'">
                <span><i class="fas fa-check-circle"></i> Online (${online.length})</span> <i class="fas fa-chevron-down"></i>
              </div>`;
              html += `<div id="grp-online">${online.map(d => buildRow(d, true)).join('')}</div>`;
            }
            if (offline.length) {
              html += `<div style="font-size:11px; font-weight:600; color:var(--danger); padding:8px; cursor:pointer; background:rgba(239,68,68,0.1); border-radius:4px; margin-bottom:6px; margin-top:10px; display:flex; justify-content:space-between; align-items:center;" onclick="document.getElementById('grp-offline').style.display = document.getElementById('grp-offline').style.display === 'none' ? 'block' : 'none'">
                <span><i class="fas fa-times-circle"></i> Offline (${offline.length})</span> <i class="fas fa-chevron-down"></i>
              </div>`;
              html += `<div id="grp-offline">${offline.map(d => buildRow(d, false)).join('')}</div>`;
            }
            dsList.innerHTML = html;
          }
        }

      } catch (e) {
        console.error('Stats error:', e);
      }
    }

    // ── Sites ────────────────────────────────────
    async function refreshSites() {
      try {
        const resp = await fetch('/api/sites');
        const data = await resp.json();
        const sites = data.sites || [];
        const enabled = sites.filter(s => s.status === 'Enabled');
        const disabled = sites.filter(s => s.status === 'Disabled');

        document.getElementById('totalSites').textContent = sites.length;
        document.getElementById('enabledSites').textContent = enabled.length;
        document.getElementById('disabledSites').textContent = disabled.length;
        document.getElementById('siteCountBadge').textContent = sites.length;

        const wrap = document.getElementById('sitesContent');
        if (sites.length === 0) {
          wrap.innerHTML = '<div class="empty-state"><i class="fas fa-globe"></i><p>No sites configured</p><button class="btn btn-primary btn-sm" style="margin-top:10px" onclick="switchPanel(\'create\')">Create first site</button></div>';
          return;
        }

        let html = '';
        if (enabled.length) {
          html += `<div class="site-group-label"><i class="fas fa-check-circle" style="color:var(--success);margin-right:5px"></i>Enabled (${enabled.length})</div>`;
          html += '<div style="overflow-x:auto"><table><thead><tr><th>#</th><th>Domain</th><th>Port / Path</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
          enabled.forEach((s, i) => {
            html += `<tr><td style="color:var(--text-3)">${i + 1}</td><td><strong>${escapeHtml(s.name)}</strong></td><td style="font-family:var(--font-mono); font-size:12px; color:var(--text-2)">${s.portPath || '-'}</td><td><span class="badge badge-success"><i class="fas fa-circle" style="font-size:5px"></i> Enabled</span></td>
            <td><div class="actions-cell">
              <button class="btn btn-warning btn-sm" onclick="toggleSite('${escapeHtml(s.name)}', this)"><i class="fas fa-pause"></i> Disable</button>
              <button class="btn btn-ghost btn-sm" onclick="editConfig('${escapeHtml(s.name)}')"><i class="fas fa-edit"></i> Edit</button>
              <button class="btn ${s.sslEnabled ? 'btn-success' : 'btn-ghost'} btn-sm" onclick="installSSLInteractive('${escapeHtml(s.name)}')"><i class="fas fa-lock"></i> SSL</button>
              <button class="btn btn-ghost btn-sm" onclick="checkDNS('${escapeHtml(s.name)}')"><i class="fas fa-globe"></i> NS</button>
              <button class="btn btn-danger btn-sm" onclick="deleteSite('${escapeHtml(s.name)}')"><i class="fas fa-trash"></i></button>
            </div></td></tr>`;
          });
          html += '</tbody></table></div>';
        }
        if (disabled.length) {
          html += `<div class="site-group-label"><i class="fas fa-pause-circle" style="color:var(--danger);margin-right:5px"></i>Disabled (${disabled.length})</div>`;
          html += '<div style="overflow-x:auto"><table><thead><tr><th>#</th><th>Domain</th><th>Port / Path</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
          disabled.forEach((s, i) => {
            html += `<tr><td style="color:var(--text-3)">${i + 1}</td><td><strong>${escapeHtml(s.name)}</strong></td><td style="font-family:var(--font-mono); font-size:12px; color:var(--text-2)">${s.portPath || '-'}</td><td><span class="badge badge-danger"><i class="fas fa-circle" style="font-size:5px"></i> Disabled</span></td>
            <td><div class="actions-cell">
              <button class="btn btn-success btn-sm" onclick="toggleSite('${escapeHtml(s.name)}', this)"><i class="fas fa-play"></i> Enable</button>
              <button class="btn btn-ghost btn-sm" onclick="editConfig('${escapeHtml(s.name)}')"><i class="fas fa-edit"></i> Edit</button>
              <button class="btn ${s.sslEnabled ? 'btn-success' : 'btn-ghost'} btn-sm" onclick="installSSLInteractive('${escapeHtml(s.name)}')"><i class="fas fa-lock"></i> SSL</button>
              <button class="btn btn-ghost btn-sm" onclick="checkDNS('${escapeHtml(s.name)}')"><i class="fas fa-globe"></i> NS</button>
              <button class="btn btn-danger btn-sm" onclick="deleteSite('${escapeHtml(s.name)}')"><i class="fas fa-trash"></i></button>
            </div></td></tr>`;
          });
          html += '</tbody></table></div>';
        }
        wrap.innerHTML = html;
      } catch (e) {
        console.error('Sites error:', e);
      }
    }

    async function reloadNginx(btn) {
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Reloading...';
      try {
        const r = await fetch('/api/nginx/reload', {
          method: 'POST', headers: { 'X-CSRF-Token': CSRF }
        });
        const d = await r.json();
        if (d.success) showToast(d.message, 'success');
        else showToast(d.error || 'Failed to reload', 'error');
      } catch { showToast('Network error', 'error'); }
      finally { btn.innerHTML = original; btn.disabled = false; }
    }

    async function toggleSite(name, btn) {
      const original = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Working...'; }
      try {
        const r = await fetch(`/api/sites/${encodeURIComponent(name)}/toggle`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF }
        });
        const d = await r.json();
        if (d.success) {
          showToast(`${name} ${d.action}. ${d.testOutput || ''}`, 'success');
          refreshSites();
        } else showToast(d.error || 'Failed', 'error');
      } catch { showToast('Network error', 'error'); }
      finally { if (btn) { btn.innerHTML = original; btn.disabled = false; } }
    }

    function deleteSite(name) {
      pendingDeleteDomain = name;
      document.getElementById('deleteDomainName').textContent = name;
      openModal('deleteModal');
    }

    async function confirmDelete() {
      const btn = document.getElementById('confirmDeleteBtn');
      const original = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Deleting...';
      try {
        const r = await fetch(`/api/sites/${encodeURIComponent(pendingDeleteDomain)}`, {
          method: 'DELETE', headers: { 'X-CSRF-Token': CSRF }
        });
        const d = await r.json();
        if (d.success) { showToast(`${pendingDeleteDomain} deleted`, 'success'); refreshSites(); }
        else showToast(d.error || 'Failed', 'error');
      } catch { showToast('Network error', 'error'); }
      finally { 
        btn.innerHTML = original; 
        btn.disabled = false; 
        closeModal('deleteModal'); 
      }
    }

    async function installSSL(name, btn) {
      if (!confirm(`Install SSL for ${name}?`)) return;
      const original = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Installing...'; }
      showToast('Installing SSL... this may take a moment', 'warning');
      try {
        const r = await fetch(`/api/sites/${encodeURIComponent(name)}/ssl`, {
          method: 'POST', headers: { 'X-CSRF-Token': CSRF }
        });
        const d = await r.json();
        if (d.success) showToast(d.message, 'success');
        else showToast(d.error || 'Failed', 'error');
      } catch { showToast('Network error', 'error'); }
      finally { if (btn) { btn.innerHTML = original; btn.disabled = false; } }
    }

    // ── Config Editor ────────────────────────────
    async function editConfig(name) {
      currentEditDomain = name;
      document.getElementById('configDomain').textContent = name;
      document.getElementById('configEditor').value = 'Loading...';
      document.getElementById('configOutput').style.display = 'none';
      openModal('configModal');

      try {
        const r = await fetch(`/api/sites/${encodeURIComponent(name)}/config`);
        const d = await r.json();
        document.getElementById('configEditor').value = d.config || '# Empty config';
      } catch {
        document.getElementById('configEditor').value = '# Failed to load config';
      }
    }

    async function checkDNS(domain) {
      showToast('Checking DNS records...', 'info');
      try {
        const res = await fetch(`/api/dns/check?domain=${encodeURIComponent(domain)}`);
        const data = await res.json();
        if(data.error) throw new Error(data.error);
        
        const aRec = data.aRecords.length ? data.aRecords.join('\n') : 'None';
        const nsRec = data.nsRecords.length ? data.nsRecords.join('\n') : 'None';
        
        document.getElementById('dnsDomainName').textContent = domain;
        document.getElementById('dnsARecords').textContent = aRec;
        document.getElementById('dnsNsRecords').textContent = nsRec;
        
        openModal('dnsModal');
      } catch(e) {
        showToast('Failed to check DNS: ' + e.message, 'error');
      }
    }

    async function saveConfig() {
      const btn = document.getElementById('saveConfigBtn');
      const config = document.getElementById('configEditor').value;
      const output = document.getElementById('configOutput');

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Testing...';
      output.style.display = 'none';

      try {
        const r = await fetch(`/api/sites/${encodeURIComponent(currentEditDomain)}/config`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ config })
        });
        const d = await r.json();
        output.style.display = 'block';
        if (d.success) {
          output.className = 'config-output success';
          output.textContent = '✓ ' + (d.testOutput || d.message);
          showToast('Config saved & nginx reloaded', 'success');
          setTimeout(() => closeModal('configModal'), 1500);
        } else {
          output.className = 'config-output error';
          output.textContent = '✗ ' + (d.error || 'Failed');
          showToast(d.error || 'Failed to save', 'error');
        }
      } catch {
        output.style.display = 'block';
        output.className = 'config-output error';
        output.textContent = '✗ Network error';
      }

      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-save"></i> Save & Reload';
    }

    // ── Create Site ──────────────────────────────
    async function createSite(e) {
      e.preventDefault();
      const btn = document.getElementById('createBtn');
      const domain = document.getElementById('newDomain').value.trim().toLowerCase();
      const port = document.getElementById('newPort').value;
      const sslEl = document.getElementById('newSSL');
      const ssl = sslEl ? sslEl.checked : false;
      const config = document.getElementById('newConfigPreview').value;
      const result = document.getElementById('createResult');

      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Creating...';
      result.innerHTML = '<div style="background:#0d1117;border:1px solid rgba(255,255,255,0.1);border-radius:6px;padding:12px;font-family:monospace;font-size:12px;color:#8b949e;max-height:200px;overflow-y:auto;" id="createLogs"><div style="color:#58a6ff;">⏳ Starting site creation...</div></div>';

      try {
        const r = await fetch('/api/sites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ domain, port, ssl: ssl ? 'on' : 'off', config })
        });
        const d = await r.json();
        const logsEl = document.getElementById('createLogs');

        if (d.logs && d.logs.length) {
          logsEl.innerHTML = d.logs.map(l => {
            const color = l.includes('✔') ? '#3fb950' : l.includes('✘') ? '#f85149' : '#8b949e';
            return '<div style="color:' + color + ';margin:2px 0;">' + escapeHtml(l) + '</div>';
          }).join('');
        }

        if (d.success) {
          logsEl.innerHTML += '<div style="color:#3fb950;font-weight:bold;margin-top:8px;">✅ Site created and enabled successfully!</div>';
          showToast('Site created!', 'success');
          document.getElementById('createForm').reset();
          setTimeout(() => switchPanel('sites'), 2000);
        } else {
          logsEl.innerHTML += '<div style="color:#f85149;font-weight:bold;margin-top:8px;">❌ ' + escapeHtml(d.error) + '</div>';
        }
      } catch {
        result.innerHTML = '<div class="alert alert-danger"><i class="fas fa-times-circle"></i> Network error</div>';
      }

      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-check"></i> Create & Enable';
    }

    // ── Preview Generation ────────────────────────
    function updatePreview() {
      const domain = document.getElementById('newDomain').value.trim().toLowerCase() || 'example.com';
      const portInput = document.getElementById('newPort').value.trim() || '3000';
      const preview = document.getElementById('newConfigPreview');
      
      let proxyOrRoot = `proxy_pass http://127.0.0.1:${portInput};`;
      if (portInput.startsWith('/')) {
        proxyOrRoot = `root ${portInput};\n        index index.html index.htm;`;
      }

      let config = `# Generated by HyPrive OS
server {
    listen 80;
    server_name ${domain} www.${domain};

    location / {
        ${proxyOrRoot}
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
`;
      preview.value = config;
    }

    // Initialize preview on load
    document.addEventListener("DOMContentLoaded", () => {
      setTimeout(updatePreview, 500);
      updateCronSummary();
    });

    // ── System Actions ────────────────────────────
    async function systemAction(action) {
      if (!confirm(`Are you sure you want to ${action} the system? This will interrupt all services.`)) return;
      try {
        const res = await fetch(`/api/system/${action}`, {
          method: 'POST',
          headers: { 'X-CSRF-Token': CSRF }
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        alert(`System is now executing ${action}...`);
      } catch (err) {
        alert('Failed: ' + err.message);
      }
    }

    // ── Cron Jobs ────────────────────────────────
    async function loadCronJobs() {
      try {
        const r = await fetch('/api/cron/config');
        const d = await r.json();
        if (r.ok) {
          document.getElementById('cronEditor').value = d.config || '';
        }
      } catch (e) {
        console.error('Failed to load crontab:', e);
      }
      await loadCronLogs();
    }

    async function saveCronConfig() {
      const config = document.getElementById('cronEditor').value;
      try {
        const r = await fetch('/api/cron/config', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ config })
        });
        const d = await r.json();
        if (d.success) {
          showToast('Crontab saved', 'success');
          loadCronJobs();
        } else {
          showToast(d.error || 'Save failed', 'error');
        }
      } catch {
        showToast('Network error', 'error');
      }
    }

    async function loadCronLogs() {
      try {
        const r = await fetch('/api/cron/logs');
        const d = await r.json();
        const logsEl = document.getElementById('cronLogs');
        if (r.ok) {
          logsEl.value = d.logs || 'No logs available.';
          logsEl.scrollTop = logsEl.scrollHeight; // auto scroll to bottom
        }
      } catch (e) {
        console.error('Failed to load cron logs:', e);
      }
    }

    // ── PM2 ──────────────────────────────────────
    async function refreshPM2() {
      try {
        const r = await fetch('/api/pm2');
        const d = await r.json();
        const tbody = document.getElementById('pm2Table');
        if (!d.processes || d.processes.length === 0) {
          tbody.innerHTML = '<tr><td colspan="6" class="empty-state" style="padding:16px"><i class="fas fa-ghost"></i><p>No PM2 processes found</p></td></tr>';
          return;
        }
        tbody.innerHTML = d.processes.map(p => {
          const isOnline = p.pm2_env && p.pm2_env.status === 'online';
          const statusBadge = isOnline ? '<span class="badge badge-success"><i class="fas fa-circle" style="font-size:5px"></i> Online</span>' : '<span class="badge badge-danger"><i class="fas fa-circle" style="font-size:5px"></i> ' + (p.pm2_env ? escapeHtml(p.pm2_env.status) : 'Stopped') + '</span>';
          const cpu = p.monit ? p.monit.cpu : 0;
          const mem = p.monit ? (p.monit.memory / 1024 / 1024).toFixed(1) : 0;
          const uptime = isOnline ? fmtUptime(Math.floor((Date.now() - p.pm2_env.pm_uptime) / 1000)) : '-';
          return `
            <tr>
              <td><strong>${escapeHtml(p.name)}</strong></td>
              <td>${statusBadge}</td>
              <td>${cpu}%</td>
              <td>${mem} MB</td>
              <td>${uptime}</td>
              <td>
                <div class="actions-cell">
                  ${isOnline ? `<button class="btn btn-warning btn-sm" onclick="pm2Action('${escapeHtml(p.name)}', 'restart')"><i class="fas fa-redo"></i> Restart</button>
                  <button class="btn btn-danger btn-sm" onclick="pm2Action('${escapeHtml(p.name)}', 'stop')"><i class="fas fa-stop"></i> Stop</button>` : `<button class="btn btn-success btn-sm" onclick="pm2Action('${escapeHtml(p.name)}', 'start')"><i class="fas fa-play"></i> Start</button>`}
                  <button class="btn btn-info btn-sm" onclick="openPm2Logs('${escapeHtml(p.name)}')"><i class="fas fa-file-alt"></i> Logs</button>
                </div>
              </td>
            </tr>
          `;
        }).join('');
      } catch (e) {
        document.getElementById('pm2Table').innerHTML = '<tr><td colspan="6" class="empty-state" style="padding:16px;color:var(--danger)">Failed to load PM2 list</td></tr>';
      }
    }

    async function pm2Action(name, action) {
      showToast(`${action}ing ${name}...`, 'info');
      try {
        const r = await fetch(`/api/pm2/${encodeURIComponent(name)}/${action}`, {
          method: 'POST',
          headers: { 'X-CSRF-Token': CSRF }
        });
        const d = await r.json();
        if (d.success) {
          showToast(d.message, 'success');
          refreshPM2();
        } else {
          showToast(d.error || 'Failed', 'error');
        }
      } catch (e) {
        showToast('Network error', 'error');
      }
    }

    async function pm2ActionGlobal(action) {
      try {
        if (action === 'backup-info') {
          const r = await fetch('/api/pm2/backup-info');
          const d = await r.json();
          showToast(d.lastBackup ? `Last backup: ${new Date(d.lastBackup).toLocaleString()}` : 'No backup found', 'info');
          return;
        }
        
        const res = await fetch(`/api/pm2/global/${action}`, {
          method: 'POST',
          headers: { 'X-CSRF-Token': CSRF }
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        showToast(`PM2 ${action} successful`, 'success');
        refreshPM2();
      } catch (e) {
        showToast('PM2 action failed: ' + e.message, 'error');
      }
    }

    let currentPm2Process = '';
    function openPm2Logs(name) {
      currentPm2Process = name;
      document.getElementById('pm2LogProcessName').textContent = name;
      document.getElementById('pm2LogOutput').textContent = 'Loading logs...';
      openModal('pm2LogsModal');
      fetchPm2Logs();
    }

    async function fetchPm2Logs() {
      if (!currentPm2Process) return;
      const lines = document.getElementById('pm2LogLines').value;
      const output = document.getElementById('pm2LogOutput');
      try {
        const r = await fetch(`/api/pm2/${encodeURIComponent(currentPm2Process)}/logs?lines=${lines}`);
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        output.textContent = d.logs || 'No logs available.';
        output.scrollTop = output.scrollHeight; // Auto-scroll to bottom
      } catch (e) {
        output.textContent = 'Failed to load logs: ' + e.message;
      }
    }

    // ── Terminal Init (xterm.js v5) ────────────────
    let term;
    let socket;
    let termInitialized = false;
    let termFitAddon;

    let sslTerm;
    let sslTermInitialized = false;
    let sslFitAddon;

    function initTerminal() {
      if (termInitialized) return;
      if (typeof Terminal === 'undefined') {
        showToast('Terminal library failed to load. Please refresh.', 'error');
        return;
      }
      termInitialized = true;
      
      const FitAddon = window.FitAddon ? window.FitAddon.FitAddon : null;
      
      term = new Terminal({
        fontSize: 10,
        fontFamily: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace",
        cursorBlink: true,
        theme: { background: '#000000', foreground: '#00ff00', cursor: '#00ff00' },
        scrollback: 5000,
        convertEol: true
      });
      
      if (FitAddon) {
        termFitAddon = new FitAddon();
        term.loadAddon(termFitAddon);
      }
      
      term.open(document.getElementById('terminal-container'));
      
      if (termFitAddon) {
        setTimeout(() => termFitAddon.fit(), 100);
      }

      socket = io({ transports: ['websocket', 'polling'] });
      
      socket.on('output', (data) => {
        term.write(data);
      });

      term.onData((data) => {
        socket.emit('input', data);
      });

      // SSL handlers
      socket.on('ssl-output', (data) => {
        if(sslTerm) sslTerm.write(data);
      });
      
      term.writeln('Welcome to HyPrive OS Web SSH!');
      term.writeln('Type a command or use the shortcuts above.');
      
      // Handle resize
      window.addEventListener('resize', () => {
        if (termFitAddon) termFitAddon.fit();
      });
    }

    let currentSSLDomain = '';

    function installSSLInteractive(domain) {
      currentSSLDomain = domain;
      document.getElementById('sslModalDomain').textContent = domain;
      document.getElementById('sslDomainBaseLabel').textContent = domain;
      document.getElementById('sslDomainWwwLabel').textContent = 'www.' + domain;
      document.getElementById('sslDomainBase').checked = true;
      document.getElementById('sslDomainWww').checked = false;
      openModal('sslModal');
      
      if (!termInitialized) {
        initTerminal();
      }

      if (!sslTermInitialized) {
        sslTermInitialized = true;
        const FitAddon = window.FitAddon ? window.FitAddon.FitAddon : null;
        
        sslTerm = new Terminal({
          fontSize: 10,
          fontFamily: "'JetBrains Mono', 'Fira Code', 'Courier New', monospace",
          cursorBlink: true,
          theme: { background: '#000000', foreground: '#10b981', cursor: '#10b981' },
          scrollback: 3000,
          convertEol: true
        });
        
        if (FitAddon) {
          sslFitAddon = new FitAddon();
          sslTerm.loadAddon(sslFitAddon);
        }
        
        sslTerm.open(document.getElementById('ssl-term-container'));
        
        if (sslFitAddon) {
          setTimeout(() => sslFitAddon.fit(), 100);
        }
        
        // Direct keyboard input to SSL terminal — THIS FIXES THE INPUT ISSUE
        sslTerm.onData((data) => {
          socket.emit('ssl-input', data);
        });
      }
      
      sslTerm.clear();
      if (sslFitAddon) setTimeout(() => sslFitAddon.fit(), 200);
    }

    function startSSLInstall() {
      const domains = [];
      if (document.getElementById('sslDomainBase').checked) domains.push(currentSSLDomain);
      if (document.getElementById('sslDomainWww').checked) domains.push('www.' + currentSSLDomain);
      
      if (domains.length === 0) {
        showToast('Please select at least one domain', 'error');
        return;
      }

      const btn = document.getElementById('sslInstallBtn');
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner"></span> Installing...';

      if (sslTerm) {
        sslTerm.clear();
        sslTerm.writeln(`\x1b[90m--- Starting SSL Installation for ${currentSSLDomain} ---\x1b[0m`);
        sslTerm.writeln(`\x1b[33m$ certbot --nginx -d ${domains.join(' -d ')}\x1b[0m\r\n`);
      }
      socket.emit('start-ssl', { domain: currentSSLDomain, domains });

      // Re-enable button after process finishes
      const handler = (data) => {
        if (data.includes('[Process exited')) {
          btn.disabled = false;
          btn.innerHTML = '<i class="fas fa-shield-alt"></i> Install SSL';
          socket.off('ssl-output', handler);

          const success = data.includes('code 0');
          if (success) {
            showToast('SSL installed successfully!', 'success');
            setTimeout(() => {
              closeModal('sslModal');
              refreshSites();
            }, 1500);
          } else {
            showToast('SSL installation failed. Check terminal for details.', 'error');
          }
        }
      };
      socket.on('ssl-output', handler);
    }

    function sendSSLInput() {
      const input = document.getElementById('sslTermInput');
      const val = input.value;
      if (!val && val !== '0') return;
      if (socket) {
        socket.emit('ssl-input', val + '\n');
        if (sslTerm) sslTerm.write(val + '\r\n');
      }
      input.value = '';
      input.focus();
    }

    function sendTerminalCommand(cmd) {
      if(socket) socket.emit('input', cmd);
    }

    // ── Init ─────────────────────────────────────
    loadNotifPrefs();
    loadStats();
    // ==========================================
    // Firewall Management
    // ==========================================
    async function loadFirewallStatus() {
      const fl = document.getElementById('firewallLoading');
      fl.style.display = 'block';
      document.getElementById('firewallNotInstalled').style.display = 'none';
      document.getElementById('firewallInactive').style.display = 'none';
      document.getElementById('firewallActive').style.display = 'none';

      if (!document.getElementById('sudoFloater').classList.contains('active')) {
        fl.innerHTML = '<i class="fas fa-lock fa-2x" style="color:var(--warning); margin-bottom:12px;"></i><h3 style="margin:0 0 8px 0; color:var(--text-1)">Sudo Authentication Required</h3><p style="margin:0 0 16px 0; color:var(--text-2); font-size:13px;">You must provide your system password to view or manage the firewall.</p><button class="btn btn-primary" onclick="openModal(\'sudoModal\')"><i class="fas fa-key"></i> Authenticate Sudo</button>';
        return;
      }
      
      fl.innerHTML = '<i class="fas fa-spinner fa-spin fa-2x"></i><p style="margin-top:10px">Checking firewall status...</p>';
      
      
      try {
        const r = await fetch('/api/firewall/status');
        const data = await r.json();
        
        document.getElementById('firewallLoading').style.display = 'none';
        
        if (!data.installed) {
          document.getElementById('firewallNotInstalled').style.display = 'block';
        } else if (!data.active) {
          document.getElementById('firewallInactive').style.display = 'flex';
        } else {
          document.getElementById('firewallActive').style.display = 'block';
          const tbody = document.getElementById('firewallRulesTable');
          tbody.innerHTML = '';
          if (data.rules && data.rules.length > 0) {
            data.rules.forEach(rule => {
              tbody.innerHTML += `
                <tr>
                  <td><span class="badge badge-dark">${rule.id}</span></td>
                  <td style="font-family:monospace; color:#a5b4fc">${rule.port}</td>
                  <td><span style="color:var(--success)">${rule.action}</span></td>
                  <td>${rule.from}</td>
                  <td style="text-align:right">
                    <button class="btn btn-ghost btn-sm" onclick="deleteFirewallRule('${rule.id}')" style="color:var(--danger)">
                      <i class="fas fa-trash"></i>
                    </button>
                  </td>
                </tr>
              `;
            });
          } else {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:20px;">No custom rules found</td></tr>`;
          }
        }
      } catch (err) {
        showToast("Failed to load firewall status", "error");
        document.getElementById('firewallLoading').style.display = 'none';
      }
      
      loadIptablesStatus(); // Automatically check iptables status whenever checking UFW
    }

    async function installFirewall() {
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      showToast("Installing UFW...", "info");
      try {
        const r = await fetch('/api/firewall/install', { method: 'POST', headers: { 'X-CSRF-Token': CSRF } });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast("UFW installed successfully", "success");
        setTimeout(loadFirewallStatus, 1000);
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    async function toggleFirewall(action) {
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      if (action === 'enable' && !confirm("Warning: Enabling firewall may drop SSH connections if port 22 is not allowed. The script will try to ensure it doesn't, but proceed with caution. Enable?")) return;
      
      showToast(`${action === 'enable' ? 'Enabling' : 'Disabling'} firewall...`, "info");
      try {
        const r = await fetch('/api/firewall/toggle', { 
          method: 'POST', 
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ action })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast(`Firewall ${action}d`, "success");
        setTimeout(loadFirewallStatus, 1000);
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    async function addFirewallRule() {
      const port = document.getElementById('newFirewallPort').value.trim();
      if (!port) return showToast("Please enter a port", "error");
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      
      try {
        const r = await fetch('/api/firewall/rule', { 
          method: 'POST', 
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ action: 'add', value: port })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        document.getElementById('newFirewallPort').value = '';
        showToast(`Port ${port} allowed`, "success");
        loadFirewallStatus();
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    async function deleteFirewallRule(id) {
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      if (!confirm(`Delete rule [${id}]?`)) return;
      
      try {
        const r = await fetch('/api/firewall/rule', { 
          method: 'POST', 
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ action: 'delete', value: id })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast(`Rule deleted`, "success");
        loadFirewallStatus();
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    async function loadIptablesStatus() {
      const loading = document.getElementById('iptablesLoading');
      if(loading) loading.style.display = 'block';
      document.getElementById('iptablesNotInstalled').style.display = 'none';
      document.getElementById('iptablesActive').style.display = 'none';

      try {
        const r = await fetch('/api/iptables/status');
        const data = await r.json();
        if(loading) loading.style.display = 'none';

        if (!data.installed) {
          document.getElementById('iptablesNotInstalled').style.display = 'block';
        } else {
          document.getElementById('iptablesActive').style.display = 'block';
          const tbody = document.getElementById('iptablesRulesTable');
          tbody.innerHTML = '';
          if (data.rules && data.rules.length > 0) {
            data.rules.forEach(rule => {
              tbody.innerHTML += `
                <tr>
                  <td><span class="badge badge-dark">${rule.id}</span></td>
                  <td style="color:var(--success)">${rule.target}</td>
                  <td style="font-family:monospace;">${rule.protocol}</td>
                  <td>${rule.source}</td>
                  <td>${rule.destination}</td>
                  <td style="color:var(--text-2)">${rule.opts}</td>
                  <td style="text-align:right">
                    <button class="btn btn-ghost btn-sm" onclick="deleteIptablesRule('${rule.id}')" style="color:var(--danger)">
                      <i class="fas fa-trash"></i>
                    </button>
                  </td>
                </tr>
              `;
            });
          } else {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state" style="padding:16px"><i class="fas fa-ghost"></i><p>No INPUT rules found</p></td></tr>';
          }
        }
      } catch (err) {
        console.error(err);
      }
    }

    async function installIptables() {
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      showToast("Installing iptables-persistent...", "info");
      document.getElementById('iptablesNotInstalled').innerHTML = '<i class="fas fa-spinner fa-spin fa-3x" style="color:var(--primary); margin-bottom:16px;"></i><h3>Installing...</h3><p style="color:var(--text-2);">This may take a minute...</p>';
      try {
        const r = await fetch('/api/iptables/install', { method: 'POST', headers: { 'X-CSRF-Token': CSRF } });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast("iptables-persistent installed!", "success");
        loadIptablesStatus();
      } catch (err) {
        showToast(err.message, "error");
        loadIptablesStatus();
      }
    }

    async function addIptablesRule() {
      const port = document.getElementById('newIptablesPort').value.trim();
      if (!port) return showToast("Please enter a port or range", "error");
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      
      try {
        const r = await fetch('/api/iptables/rule', { 
          method: 'POST', 
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ action: 'add', value: port })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        document.getElementById('newIptablesPort').value = '';
        showToast(`Port ${port} allowed via iptables`, "success");
        loadIptablesStatus();
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    async function deleteIptablesRule(id) {
      if (!document.getElementById('sudoFloater').classList.contains('active')) return showToast("Sudo password required", "error");
      if (!confirm(`Delete iptables INPUT rule [Line ${id}]?`)) return;
      
      try {
        const r = await fetch('/api/iptables/rule', { 
          method: 'POST', 
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ action: 'delete', value: id })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast(`Rule deleted and saved`, "success");
        loadIptablesStatus();
      } catch (err) {
        showToast(err.message, "error");
      }
    }

    // Interval removed, was undefined
    refreshSites();

    function switchFwTab(tab) {
      if (tab === 'ufw') {
        document.getElementById('fw-tab-ufw').style.display = 'block';
        document.getElementById('fw-tab-iptables').style.display = 'none';
        document.getElementById('btnTabUfw').className = 'btn btn-primary';
        document.getElementById('btnTabUfw').style.background = '';
        document.getElementById('btnTabUfw').style.border = '';
        document.getElementById('btnTabUfw').style.color = '';
        document.getElementById('btnTabIptables').className = 'btn';
        document.getElementById('btnTabIptables').style.background = 'transparent';
        document.getElementById('btnTabIptables').style.border = '1px solid var(--border)';
        document.getElementById('btnTabIptables').style.color = 'var(--text-1)';
      } else {
        document.getElementById('fw-tab-ufw').style.display = 'none';
        document.getElementById('fw-tab-iptables').style.display = 'block';
        document.getElementById('btnTabIptables').className = 'btn btn-primary';
        document.getElementById('btnTabIptables').style.background = '';
        document.getElementById('btnTabIptables').style.border = '';
        document.getElementById('btnTabIptables').style.color = '';
        document.getElementById('btnTabUfw').className = 'btn';
        document.getElementById('btnTabUfw').style.background = 'transparent';
        document.getElementById('btnTabUfw').style.border = '1px solid var(--border)';
        document.getElementById('btnTabUfw').style.color = 'var(--text-1)';
      }
    }

    // Close modals on Escape
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
      }
    });

    // Close modals on overlay click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) overlay.classList.remove('active');
      });
    });
    async function submitSudoPass() {
      const pass = document.getElementById('sudoPassInput').value;
      if (!pass) return showToast('Password required', 'warning');
      
      showToast('Authenticating...', 'info');
      try {
        const res = await fetch('/api/sudo-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ password: pass })
        });
        const data = await res.json();
        if (data.error) throw new Error(data.error);
        
        showToast('Sudo password accepted!', 'success');
        document.getElementById('sudoFloater').classList.add('active');
        document.getElementById('sudoFloater').innerHTML = '<i class="fas fa-lock"></i>';
        closeModal('sudoModal');
        document.getElementById('sudoPassInput').value = '';
        if (document.getElementById('panel-firewall').classList.contains('active')) {
          loadFirewallStatus();
        }
      } catch (e) {
        showToast(e.message, 'error');
        document.getElementById('sudoFloater').classList.remove('active');
        document.getElementById('sudoFloater').innerHTML = '<i class="fas fa-unlock"></i>';
      }
    }

    // ── Settings ──────────────────────────────────
    async function loadSettings() {
      try {
        const r = await fetch('/api/settings');
        if (!r.ok) throw new Error('Network response was not ok');
        const d = await r.json();
        
        const container = document.getElementById('ipListContainer');
        container.innerHTML = '';
        
        let ips = (d.settings.allowedIps || '*').split(',').map(s => s.trim()).filter(Boolean);
        if (ips.length === 0) ips = ['*'];
        
        ips.forEach(ip => addIpRow(ip));
        
        if (d.settings.ide_allowed_root) {
          document.getElementById('ideAllowedRootInput').value = d.settings.ide_allowed_root;
        } else {
          document.getElementById('ideAllowedRootInput').value = "/home/";
        }
      } catch (e) {
        showToast('Failed to load settings', 'error');
      }
    }

    function addIpRow(value = '') {
      const container = document.getElementById('ipListContainer');
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.gap = '8px';
      row.innerHTML = `
        <input type="text" class="form-control ip-input" value="${value}" style="flex:1" placeholder="e.g. 192.168.1.1 or *" />
        <button class="btn btn-ghost" onclick="this.parentElement.remove()" style="padding: 0 12px;"><i class="fas fa-minus" style="color:var(--danger)"></i></button>
      `;
      container.appendChild(row);
    }

    async function saveSettings() {
      const inputs = document.querySelectorAll('.ip-input');
      const allowedIps = Array.from(inputs).map(i => i.value.trim()).filter(Boolean).join(',');
      const ideAllowedRoot = document.getElementById('ideAllowedRootInput').value.trim();
      
      const emailConfig = {
        host: document.getElementById('emailHost').value.trim(),
        port: parseInt(document.getElementById('emailPort').value.trim()) || 465,
        user: document.getElementById('emailUser').value.trim(),
        pass: document.getElementById('emailPass').value.trim(),
        from: document.getElementById('emailFrom').value.trim(),
        to: document.getElementById('emailTo').value.trim(),
        cc: document.getElementById('emailCc').value.trim(),
        bcc: document.getElementById('emailBcc').value.trim(),
      };
      
      const twoFactorEnabled = document.getElementById('twoFactorEnabled').checked;

      try {
        const r = await fetch('/api/settings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ 
            allowedIps: allowedIps || '*', 
            ide_allowed_root: ideAllowedRoot || undefined,
            emailConfig,
            twoFactorEnabled
          })
        });
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        showToast('Settings saved successfully', 'success');
      } catch (e) {
        showToast(e.message, 'error');
      }
    }

    // ── Visual Cron Builder ─────────────────────────
    async function testVisualCron() {
      const url = document.getElementById('cronUrlBuilder').value;
      const method = document.getElementById('cronMethodBuilder').value;
      const out = document.getElementById('cronTestOutput');
      if (!url) return showToast('Please enter an API URL', 'error');
      
      out.style.display = 'block';
      out.textContent = 'Executing test run... Please wait.';
      try {
        const r = await fetch('/api/cron/test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
          body: JSON.stringify({ url, method })
        });
        const d = await r.json();
        if (d.success) {
          out.textContent = `Status: ${d.status} (${d.timeMs}ms)\n\nResponse:\n${d.response}`;
        } else {
          out.textContent = `Error: ${d.error}`;
        }
      } catch (e) {
        out.textContent = `Network Error: ${e.message}`;
      }
    }

    function setCronTab(mode) {
      document.getElementById('cronFreqMode').value = mode;
      document.querySelectorAll('.cron-tab').forEach(el => {
        el.classList.toggle('active', el.getAttribute('data-value') === mode);
      });
      toggleCronFields();
      updateCronSummary();
    }

    function toggleCronDay(el) {
      el.classList.toggle('active');
      updateCronSummary();
    }

    function toggleCronDate(el) {
      el.classList.toggle('active');
      updateCronSummary();
    }

    function updateCronSummary() {
      const mode = document.getElementById('cronFreqMode').value;
      let text = '';
      let code = '';

      if (mode === 'minute') {
        text = 'Every single minute.';
        code = '* * * * *';
      } else if (mode === 'hourly') {
        text = 'Hourly (at minute 0).';
        code = '0 * * * *';
      } else if (mode === 'daily') {
        const timeVal = document.getElementById('cronTimeInput').value || '00:00';
        const [hour, minute] = timeVal.split(':');
        const h = parseInt(hour, 10);
        const m = parseInt(minute, 10);
        text = `Daily at ${hour}:${minute}.`;
        code = `${m} ${h} * * *`;
      } else if (mode === 'weekly') {
        const timeVal = document.getElementById('cronTimeInput').value || '00:00';
        const [hour, minute] = timeVal.split(':');
        const h = parseInt(hour, 10);
        const m = parseInt(minute, 10);
        
        const activeDays = Array.from(document.querySelectorAll('.cron-day-btn.active'));
        const dayNames = activeDays.map(el => el.getAttribute('data-full'));
        const dayVals = activeDays.map(el => el.getAttribute('data-value'));
        
        if (dayVals.length === 0) {
          text = 'No day of week selected.';
          code = `? ? * * ?`;
        } else if (dayVals.length === 7) {
          text = `Daily at ${hour}:${minute}.`;
          code = `${m} ${h} * * *`;
        } else {
          text = `At ${hour}:${minute} on: ${dayNames.join(', ')}.`;
          code = `${m} ${h} * * ${dayVals.join(',')}`;
        }
      } else if (mode === 'monthly') {
        const timeVal = document.getElementById('cronTimeInput').value || '00:00';
        const [hour, minute] = timeVal.split(':');
        const h = parseInt(hour, 10);
        const m = parseInt(minute, 10);
        
        const activeDates = Array.from(document.querySelectorAll('.cron-date-btn.active')).map(el => parseInt(el.getAttribute('data-value'), 10)).sort((a,b) => a-b);
        
        if (activeDates.length === 0) {
          text = 'No day of month selected.';
          code = `? ? ? * *`;
        } else {
          const dateStrings = activeDates.map(d => {
            if (d === 1 || d === 21 || d === 31) return d + 'st';
            if (d === 2 || d === 22) return d + 'nd';
            if (d === 3 || d === 23) return d + 'rd';
            return d + 'th';
          });
          text = `At ${hour}:${minute} on: ${dateStrings.join(', ')} of every month.`;
          code = `${m} ${h} ${activeDates.join(',')} * *`;
        }
      } else if (mode === 'custom') {
        const customExp = document.getElementById('cronCustomInput').value.trim() || '* * * * *';
        text = 'Custom cron expression.';
        code = customExp;
      }

      const summaryTextEl = document.getElementById('cronSummaryText');
      const summaryCodeEl = document.getElementById('cronSummaryCode');
      if (summaryTextEl) summaryTextEl.textContent = text;
      if (summaryCodeEl) summaryCodeEl.textContent = code;
    }

    function toggleCronFields() {
      const mode = document.getElementById('cronFreqMode').value;
      
      // Hide all toggleable fields first
      document.querySelectorAll('.cron-field-toggle').forEach(el => el.style.display = 'none');
      
      if (mode === 'daily') {
        document.getElementById('cronTimeField').style.display = 'block';
      } else if (mode === 'weekly') {
        document.getElementById('cronTimeField').style.display = 'block';
        document.getElementById('cronDOWField').style.display = 'block';
      } else if (mode === 'monthly') {
        document.getElementById('cronTimeField').style.display = 'block';
        document.getElementById('cronDOMField').style.display = 'block';
      } else if (mode === 'custom') {
        document.getElementById('cronCustomField').style.display = 'block';
      }
    }

    async function addVisualCron() {
      const mode = document.getElementById('cronFreqMode').value;
      const url = document.getElementById('cronUrlBuilder').value.trim();
      const method = document.getElementById('cronMethodBuilder').value;
      
      if (!url) return showToast('Please enter an API URL', 'error');
      
      // Force update summary first to get latest code
      updateCronSummary();
      
      const freq = document.getElementById('cronSummaryCode').textContent.trim();
      if (freq.includes('?')) {
        return showToast('Please configure the schedule properly', 'error');
      }
      
      // Build raw cron line
      const rawLine = `${freq} curl -s -X ${method} "${url}" >> /tmp/cron_api.log 2>&1`;
      
      const editor = document.getElementById('cronEditor');
      let currentVal = editor.value.trim();
      if (currentVal && !currentVal.endsWith('\n')) currentVal += '\n';
      currentVal += rawLine + '\n';
      editor.value = currentVal;
      
      await saveCronConfig();
      showToast('Visual job added to crontab!', 'success');
      document.getElementById('cronUrlBuilder').value = '';
    }

    // ── Folder Picker ───────────────────────────────
    let currentPickerPath = '';
    let currentPickerParent = null;

    async function loadFolderPicker(dir = '') {
      try {
        const r = await fetch(`/api/system/folders?dir=${encodeURIComponent(dir)}`);
        const d = await r.json();
        if (d.error) throw new Error(d.error);
        
        currentPickerPath = d.current;
        currentPickerParent = d.parent;
        
        document.getElementById('fpCurrentPath').value = currentPickerPath;
        document.getElementById('fpUpBtn').disabled = !currentPickerParent;
        
        const listEl = document.getElementById('fpFolderList');
        if (d.folders.length === 0) {
          listEl.innerHTML = '<div style="color:#666; font-size:12px; padding:10px;">(Empty)</div>';
        } else {
          listEl.innerHTML = d.folders.map(f => `
            <div style="padding:6px 10px; cursor:pointer; color:#ccc; font-size:13px; display:flex; align-items:center; gap:8px; border-radius:4px;" 
                 onmouseover="this.style.background='#333'" 
                 onmouseout="this.style.background='transparent'"
                 onclick="loadFolderPicker('${escapeHtml(currentPickerPath + '/' + f).replace(/\\/g, '\\\\')}')">
              <i class="fas fa-folder" style="color:#fcd53f;"></i> <span>${escapeHtml(f)}</span>
            </div>
          `).join('');
        }
      } catch (e) {
        showToast('Failed to load folders: ' + e.message, 'error');
      }
    }

    function openFolderPicker() {
      const currentInput = document.getElementById('ideAllowedRootInput').value.trim();
      loadFolderPicker(currentInput || '/home');
      openModal('folderPickerModal');
    }

    function loadFolderPickerParent() {
      if (currentPickerParent) {
        loadFolderPicker(currentPickerParent);
      }
    }

    function confirmFolderSelection() {
      document.getElementById('ideAllowedRootInput').value = currentPickerPath;
      closeModal('folderPickerModal');
    }
    // ==================== GIT MANAGEMENT ====================
    async function loadGitStatus() {
      try {
        const res = await fetch('/api/git/status');
        const data = await res.json();
        
        if (!data.installed) {
          document.getElementById('gitNotInstalled').style.display = 'block';
          document.getElementById('gitInstalledView').style.display = 'none';
        } else {
          document.getElementById('gitNotInstalled').style.display = 'none';
          document.getElementById('gitInstalledView').style.display = 'block';
          
          document.getElementById('gitNameInput').value = data.name || '';
          document.getElementById('gitEmailInput').value = data.email || '';
          
          if (data.remote) {
            document.getElementById('gitCurrentRemote').innerHTML = `Linked to: <a href="${data.remote}" target="_blank" style="color:var(--primary)">${data.remote}</a>`;
            document.getElementById('gitRemoteInputWrap').style.display = 'none';
            document.getElementById('gitRemoteActionBtn').innerHTML = '<i class="fas fa-unlink"></i> Disconnect';
            document.getElementById('gitRemoteActionBtn').onclick = () => manageGitRemote('remove');
            document.getElementById('gitRemoteActionBtn').className = 'btn btn-danger';
          } else {
            document.getElementById('gitCurrentRemote').innerHTML = `No remote repository linked.`;
            document.getElementById('gitRemoteInputWrap').style.display = 'flex';
            document.getElementById('gitRemoteUrl').value = '';
            document.getElementById('gitRemoteActionBtn').innerHTML = '<i class="fas fa-link"></i> Link Repo';
            document.getElementById('gitRemoteActionBtn').onclick = () => manageGitRemote('add');
            document.getElementById('gitRemoteActionBtn').className = 'btn btn-primary';
          }
        }
      } catch (err) {
        showToast('Failed to load Git status', 'error');
      }
    }

    async function installGit() {
      const btn = document.getElementById('installGitBtn');
      const original = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Installing...';
      btn.disabled = true;
      try {
        const res = await fetch('/api/git/install', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': CSRF
          }
        });
        const data = await res.json();
        if (data.success) {
          showToast('Git installed successfully!', 'success');
          loadGitStatus();
        } else {
          throw new Error(data.error);
        }
      } catch (err) {
        showToast(err.message, 'error');
      } finally {
        btn.innerHTML = original;
        btn.disabled = false;
      }
    }

    async function saveGitConfig() {
      const name = document.getElementById('gitNameInput').value;
      const email = document.getElementById('gitEmailInput').value;
      try {
        const res = await fetch('/api/git/config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': CSRF
          },
          body: JSON.stringify({ name, email })
        });
        const data = await res.json();
        if (data.success) {
          showToast('Git identity saved!', 'success');
          loadGitStatus();
        } else throw new Error(data.error);
      } catch (err) {
        showToast(err.message, 'error');
      }
    }

    async function manageGitRemote(action) {
      const url = document.getElementById('gitRemoteUrl').value;
      try {
        const res = await fetch('/api/git/remote', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': CSRF
          },
          body: JSON.stringify({ action, url })
        });
        const data = await res.json();
        if (data.success) {
          showToast(action === 'add' ? 'Remote linked!' : 'Remote disconnected!', 'success');
          loadGitStatus();
        } else throw new Error(data.error);
      } catch (err) {
        showToast(err.message, 'error');
      }
    }
