const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const readline = require('readline');

const AUTH_FILE = path.join(__dirname, 'HyprivOS.config.json');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log("\n==================================");
console.log("  HyPrive OS Password Reset Tool");
console.log("==================================\n");

function loadAuthPrefs() {
  try { return JSON.parse(fs.readFileSync(AUTH_FILE, 'utf8')); }
  catch(e) { return { adminUser: 'admin', adminPassHash: null, twoFactorEnabled: false }; }
}
function saveAuthPrefs(prefs) {
  try {
    fs.writeFileSync(AUTH_FILE, JSON.stringify(prefs, null, 2));
    return true;
  } catch (e) {
    console.error("Failed to write to HyprivOS.config.json", e.message);
    return false;
  }
}

rl.question('Enter new administrator username (leave blank to keep current): ', (user) => {
  rl.question('Enter new password: ', (pass) => {
    if (!pass) {
      console.log('Password cannot be empty. Aborting.');
      process.exit(1);
    }
    
    rl.question('Disable 2-Step Authentication (OTP)? (y/N): ', (disable2FA) => {
      const auth = loadAuthPrefs();
      if (user.trim()) {
        auth.adminUser = user.trim();
      }
      
      const salt = bcrypt.genSaltSync(10);
      auth.adminPassHash = bcrypt.hashSync(pass, salt);
      
      if (disable2FA.toLowerCase() === 'y') {
        auth.twoFactorEnabled = false;
        console.log('2-Step Authentication disabled.');
      }
      
      if (saveAuthPrefs(auth)) {
        console.log(`\nPassword reset successfully for user: ${auth.adminUser}`);
        console.log('You can now log in to the HyPrive OS dashboard.\n');
      }
      process.exit(0);
    });
  });
});
