const { execFile } = require('child_process');
const util = require('util');
const execFileAsync = util.promisify(execFile);

async function testFetch(domain) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(`http://${domain}`, { signal: controller.signal, redirect: 'follow' });
    clearTimeout(timeoutId);
    console.log('fetch success:', domain, res.status);
  } catch(e) {
    console.log('fetch error:', domain, e.message);
  }
}

async function testCurl(domain) {
  try {
    const { stdout } = await execFileAsync('curl', ['-s', '-o', '/dev/null', '-w', '%{http_code}', '-m', '5', '-L', '-k', `http://${domain}`]);
    console.log('curl success:', domain, stdout);
  } catch (e) {
    console.log('curl error:', domain, e.message);
  }
}

async function run() {
  await testFetch('visit.digitrand.in');
  await testCurl('visit.digitrand.in');
  await testFetch('ftp.digitrand.com');
  await testCurl('ftp.digitrand.com');
}
run();
