const fs = require('fs');
async function testAll() {
  const sites = fs.readdirSync('/etc/nginx/sites-enabled');
  for (const site of sites) {
    if (site === 'default') continue;
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      const res = await fetch(`http://${site}`, { signal: controller.signal, redirect: 'follow' });
      clearTimeout(timeoutId);
      console.log(`fetch success: ${site} ${res.status}`);
    } catch(e) {
      console.log(`fetch error: ${site} ${e.message}`);
    }
  }
}
testAll();
